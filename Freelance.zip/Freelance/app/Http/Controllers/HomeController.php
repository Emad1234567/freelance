<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Cart;
use Illuminate\Support\Facades\Auth;
use App\Models\BillingDetails;
use App\Models\ConfirmOrder;
use App\Models\Comment;
use App\Models\CommentReply;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    // public function __construct()
    // {
    //     $this->middleware('auth');
    // }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        $title = "Home";
        $featured = Product::where('status','featured')->limit(6)->get();
         $featured_count = $featured->count();
        $recent_release = Product::where('status','active')
        ->orderBy('created_at','desc')
        ->limit(9)
        ->get();
        $recent_release_count = $recent_release->count();
         return view('home',compact('title','featured','recent_release','recent_release_count','featured_count'));
    }

    public function remove_product_from_cart($id){

        Cart::where('id',$id)->delete();
        return redirect()->back()->with('message','Product Remove From Your Cart');
    }

    public function cart(){

        $title = "My Cart";
        $my_cart_count =Cart::where('user_id',Auth::user()->id)->count();
        $my_cart =Cart::where('user_id',Auth::user()->id)->get();

        return view('cart',compact('title','my_cart','my_cart_count'));
    }

    public function add_to_cart_from_front($id){

        $cart = new Cart;
        $cart->user_id = Auth::user()->id;
        $cart->product_id = $id;
        $cart->quanity = 1;
        $cart->save();
        return redirect()->back()->with('success','Success! Product added into your cart!');

    }

    public function checkout(){
        $title = "CheckOut";
        $selected_product = Cart::where('user_id',Auth::user()->id)->get();
        return view('checkout',compact('title','selected_product'));
    }

    public function save_billing_details(Request $request){

        $BillingDetails = new BillingDetails;
        $BillingDetails->payer_id = Auth::user()->id;
        $BillingDetails->first_name = $request->first_name;
        $BillingDetails->last_name = $request->last_name;
        $BillingDetails->email = $request->email;
        $BillingDetails->company = $request->company;
        $BillingDetails->country = $request->country;
        $BillingDetails->save();
        return response()->json([
            'success' => 'billing_Save'
        ]);
    }

    public function order_confirm(Request $request){
    //   $seprate_ids = str_replace(',','',$request->product_id);
    //    $final = str_replace('  ',' ',$seprate_ids);
    //   $array = explode(' ', $final);
    //     $make_array = array([

    //         'ids'=>$array,
    //     ]);

        $ConfirmOrder = new ConfirmOrder;
        $ConfirmOrder->user_id = Auth::user()->id;
        $ConfirmOrder->product_id = $request->product_id;
        $ConfirmOrder->save();
        Cart::where('user_id',Auth::user()->id)->delete();
        return redirect('Thnak-you');
    }

    public function thankyou(){

        $title = "Thank you";
        return view('thankyou',compact('title'));
    }

    public function search_product(Request $request){

        if($request->has('q')){
             $query = $request->q;
        }
        $title = $query;
        $product_count = Product::where('title','LIKE','%'.$query.'%')->count();
         $product = Product::where('title','LIKE','%'.$query.'%')->paginate('12');
        return view('search_result',compact('product_count','product','query','title'));
    }

    public function product_details($id,$slug){
        $product = Product::find($id)->first();
        $title = $product->title;
        $meta= '<meta name="title" content="'.$product->title.'">
        <meta name="description" content="'.$product->details.'">
        <meta name="keywords" content="demo, ok, like, writting, ">
        <meta name="robots" content="index, follow">
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8">

        <meta property="og:url"           content="http://127.0.0.1:8000/Product-Details/'.$product->id.'/'.str_replace(' ','-',$product->title).'" />
        <meta property="og:type"          content="website" />
        <meta property="og:title"         content="Your Website Title" />
        <meta property="og:description"   content="'.$product->details.'" />
        <meta property="og:image"         content="/front/img/marketplace/products/'.$product->product_thumbnail()->product_image.'" />';

        $comment_count = Comment::where('product_id',$id)->count();
       $comment = Comment::where('product_id',$id)->get();
             $related_product_count = Product::where('title','LIKE','%'.$product->title.'%')->count();

        $related_product = Product::where('title','LIKE','%'.$product->title.'%')->limit(4)->get();
         return view('product_details',compact('product','title','meta','comment_count','comment','related_product','related_product_count','id'));
    }

    public function post_comment(Request $request,$id){

        $comment = new Comment;
        $comment->user_id = Auth::user()->id;
        $comment->product_id = $id;
        $comment->comment = $request->comment;
        $comment->save();
        return redirect()->back()->with('comment_success','Your Comment Is Now Publish');
    }

    public function post_reply(Request $request,$id){

        $reply = new CommentReply;
        $reply->user_id = Auth::user()->id;
        $reply->comment_id = $id;
        $reply->comment = $request->replay;
        $reply->save();
        return redirect()->back()->with('reply','Your Reply Is Now Publish');
    }



}

