<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Str;
use App\Models\Category;
use App\Models\Product;
use App\Models\AppSetting;

class AdminController extends Controller
{
    public function catagories()
    {
        $categorie = Category::where('is_deletd',0)->get();
        return view('/Admin/categories',compact('categorie'));
    }

    public function add_category(Request $request)
    {
        $category = new Category;
        $category->name = $request->name;
        $category->status = 'active';
        $category->save();

        return redirect()->back()->with('msg','Category Added Successfully');
    }

     public function edit_category_view($id)
     {
        $category = Category::where('id',$id)->first();

        return view('/Admin/category_edit',compact('category'));
     }
    public function edit_category(Request $request,$id)
    {
       $category = Category::where('id',$id)->update(array(
         'name'=>$request->name,
       ));

      
       return redirect('/Admin/Categories')->with('msg','Category Updated Successfully');
    }

    public function delete_category($id)
    {
        $category = Category::where('id',$id)->update(array(
            'is_deletd'=>1,
          ));

          return redirect()->back()->with('msg','Category Deleted Successfully');
    }


    public function product_view()
    {
       $product = Product::where('is_deletd',0)->get();
        return view('/Admin/products',compact('product'));
    }

    public function add_product(Request $request)
    {
        $product = new Product;
        $product->title = $request->name;
        $product->price = $request->price;
        $product->category_id = $request->category;
        $product->details = $request->detail;
        $product->status = 'active';
        $product->save();

        return redirect()->back()->with('msg','Product Added Successfully');

    }

    public function edit_produt_view($id)
    {
       $product =  Product::where('id',$id)->first();
       return view('/Admin/product_edit',compact('product'));     
    }

    public function edit_product(Request $request,$id)
    {
        Product::where('id',$id)->update(array(
            'title'=>$request->name,
            'price'=>$request->price,
            'category_id'=>$request->category,
            'details'=>$request->detail,

        ));

        return redirect('/Admin/Products')->with('msg','Product Updated Successfully');

    }

    public function product_delete($id)
    {
        Product::where('id',$id)->update(array(
            'is_deletd'=>1,
        ));

        return redirect()->back()->with('msg','Product Deleted Successfully');
    }

    public function site_setting_view()
    {
        $app_setting = AppSetting::first();
        return view('/Admin/site_setting',compact('app_setting'));
    }

    public function save_site_setting(Request $request)
    {
        if($request->setting == "website_name"){
            
            AppSetting::where('id',1)->update(array(

         'app_name'=>$request->website_name,
     ));

     return redirect()->back()->with('status1','App Name Updated');

     }
     
     if($request->setting == "main_heading"){
            
        AppSetting::where('id',1)->update(array(

     'app_main_heading'=>$request->main_heading,
 ));

 return redirect()->back()->with('status2','Main Heading Updated');

 }
     
     
 if($request->setting == "sub_heading"){
            
    AppSetting::where('id',1)->update(array(

 'app_sub_heading'=>$request->sub_heading,
));

return redirect()->back()->with('status3','Main Heading Updated');

}
     
     if($request->setting == "site_logo"){
          if($request->hasFile('logo_file')){
               
          $attechment  = $request->file('logo_file');
           $img_2 =  time().$attechment->getClientOriginalName();
         $attechment->move(public_path('site_logo'),$img_2);
             
          $image_name = explode('.', $img_2);
         $extention = end($image_name);
         $extention = Str::lower($extention);
         
         if($extention == "png" || $extention == "jpg" || $extention == "jpeg"){
             
            AppSetting::where('id',1)->update(array(
               
               'app_logo'=>$img_2 ??''
             ));
              return redirect()->back()->with('status4','Site Logo Updated');
         }else{
             
              return redirect()->back()->with('status4','File Extension Not Supported');
             
         }

         
          }else{
              
              return redirect()->back()->with('status4','Select Logo File From Your Device Before Proceeding.');
              
          }
         
    }
     
    if($request->setting == "top_noti_1"){
            
        AppSetting::where('id',1)->update(array(
    
     'top_bar_noti1'=>$request->top_noti_1,
    ));
    
    return redirect()->back()->with('status5','Main Heading Updated');
    
    }
    
    if($request->setting == "top_noti_2"){
            
        AppSetting::where('id',1)->update(array(
    
     'top_bar_noti2'=>$request->top_noti_2,
    ));
    
    return redirect()->back()->with('status6','Main Heading Updated');
    
    }
    if($request->setting == "top_noti_3"){
            
        AppSetting::where('id',1)->update(array(
    
     'top_bar_noti3'=>$request->top_noti_3,
    ));
    
    return redirect()->back()->with('status7','Main Heading Updated');
    
    }

    if($request->setting == "facebook"){
            
        AppSetting::where('id',1)->update(array(
    
     'facebook'=>$request->facebook,
    ));
    
    return redirect()->back()->with('status8','Main Heading Updated');
    
    }

    if($request->setting == "youtube"){
            
        AppSetting::where('id',1)->update(array(
    
     'youtube'=>$request->youtube,
    ));
    
    return redirect()->back()->with('status9','Main Heading Updated');
    
    }

    if($request->setting == "linkdin"){
            
        AppSetting::where('id',1)->update(array(
    
     'linkedin'=>$request->linkdin,
    ));
    
    return redirect()->back()->with('status10','Main Heading Updated');
    
    }

    if($request->setting == "twitter"){
            
        AppSetting::where('id',1)->update(array(
    
     'twitter'=>$request->twitter,
    ));
    
    return redirect()->back()->with('status11','Main Heading Updated');
    
    }

    if($request->setting == "instagram"){
            
        AppSetting::where('id',1)->update(array(
    
     'insta'=>$request->instagram,
    ));
    
    return redirect()->back()->with('status12','Main Heading Updated');
    
    }


    }
}
