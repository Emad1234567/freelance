<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    use HasFactory;

    public function user_info(){

        return User::where('id',$this->id)->first();
    }

    public function comment_reply_count(){

        return CommentReply::where('comment_id',$this->id)->count();

    }

      public function comment_reply(){

        return CommentReply::where('comment_id',$this->id)->first();

    }

}
