<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use App\Models\ProductImage;

class Product extends Model
{
    use HasFactory;

    public function category(){

     	return $this->belongsTo('App\Models\Category','category_id','id');
    }

    public function product_thumbnail(){

        return ProductImage::where('product_id',$this->id)->first();
    }
     public function product_all_imgs(){

        return ProductImage::where('product_id',$this->id)->get();
    }
}
