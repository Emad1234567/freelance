<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    use HasFactory;

    public function total_price(){

     	return $this->belongsTo('App\Models\Product','product_id','id');
    }

    public function product_thumbnail(){
        return ProductImage::where('product_id',$this->product_id)->first();
    }

    public function product_details(){
        return Product::where('id',$this->product_id)->first();
    }
}
