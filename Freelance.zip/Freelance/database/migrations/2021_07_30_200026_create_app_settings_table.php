<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAppSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('app_settings', function (Blueprint $table) {
            $table->id();
            $table->string('app_logo')->nullable();
            $table->string('app_name')->nullable();
            $table->string('app_main_heading')->nullable();
            $table->string('app_sub_heading')->nullable();
             $table->string('facebook')->nullable();
            $table->string('youtube')->nullable();
            $table->string('insta')->nullable();
            $table->string('twitter')->nullable();
            $table->string('linkedin')->nullable();
            $table->string('feature_text1')->nullable();
            $table->string('feature_text2')->nullable();
            $table->string('feature_text3')->nullable();
            $table->string('feature_text4')->nullable();
            $table->string('feature_text5')->nullable();
            $table->string('feature_text6')->nullable();
            $table->string('feature_text7')->nullable();
            $table->string('feature_text8')->nullable();
            $table->string('top_bar_noti1')->nullable();
            $table->string('top_bar_noti2')->nullable();
            $table->string('top_bar_noti3')->nullable();



            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('app_settings');
    }
}
