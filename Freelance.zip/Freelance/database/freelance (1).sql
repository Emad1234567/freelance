-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2021 at 10:09 PM
-- Server version: 10.4.20-MariaDB
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `freelance`
--

-- --------------------------------------------------------

--
-- Table structure for table `app_settings`
--

CREATE TABLE `app_settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `app_logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_main_heading` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `app_sub_heading` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `insta` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_bar_noti1` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_bar_noti2` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `top_bar_noti3` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_qr_code` varchar(200) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `app_settings`
--

INSERT INTO `app_settings` (`id`, `app_logo`, `app_name`, `app_main_heading`, `app_sub_heading`, `facebook`, `youtube`, `insta`, `twitter`, `linkedin`, `top_bar_noti1`, `top_bar_noti2`, `top_bar_noti3`, `payment_qr_code`, `created_at`, `updated_at`) VALUES
(1, '1628710613logo-dark.png', 'My Website', 'Main Heading', 'Sub heading', 'https://www.facebook.com/', 'https://www.youtube.com/', 'https://www.Instagram.com', 'https://twitter.com/', 'https://www.Linkdin.com', 'Mynoti1', 'mynoti2', 'noti3', NULL, '2021-08-11 14:28:17', '2021-08-11 14:47:39');

-- --------------------------------------------------------

--
-- Table structure for table `billing_details`
--

CREATE TABLE `billing_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `payer_id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `payment_method` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_amount` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `billing_details`
--

INSERT INTO `billing_details` (`id`, `payer_id`, `first_name`, `last_name`, `email`, `company`, `country`, `payment_method`, `pay_amount`, `created_at`, `updated_at`) VALUES
(1, 1, 'zain', 'malik', 'demo@demo.com', 'xnm', 'India', NULL, NULL, '2021-08-02 15:32:51', '2021-08-02 15:32:51'),
(2, 1, 'zain', 'malik', 'demo@demo.com', 'znm', 'India', NULL, NULL, '2021-08-02 15:46:43', '2021-08-02 15:46:43'),
(3, 1, 'zain', 'malik', 'demo@demo.com', 'znm', 'India', NULL, NULL, '2021-08-02 15:47:10', '2021-08-02 15:47:10'),
(4, 1, 'zain', 'malik', 'demo@demo.com', 'znm', 'India', NULL, NULL, '2021-08-02 15:47:54', '2021-08-02 15:47:54'),
(5, 1, 'zain', 'malik', 'demo@demo.com', 'znm', 'India', NULL, NULL, '2021-08-02 15:48:56', '2021-08-02 15:48:56'),
(6, 1, 'zain', 'malik', 'demo@demo.com', 'znm', 'India', NULL, NULL, '2021-08-02 15:49:16', '2021-08-02 15:49:16'),
(7, 1, 'zain', 'malik', 'demo@demo.com', 'zn', 'India', NULL, NULL, '2021-08-02 15:52:00', '2021-08-02 15:52:00'),
(8, 1, 'zain', 'malik', 'demo@demo.com', 'znm', 'India', NULL, NULL, '2021-08-02 15:55:29', '2021-08-02 15:55:29'),
(9, 1, 'zain', 'malik', 'demo@demo.com', 'znm', 'India', NULL, NULL, '2021-08-02 15:57:17', '2021-08-02 15:57:17'),
(10, 1, 'zain', 'malik', 'demo@demo.com', 'znm', 'India', NULL, NULL, '2021-08-02 15:57:45', '2021-08-02 15:57:45'),
(11, 1, 'zain', 'malik', 'demo@demo.com', 'znm', 'India', NULL, NULL, '2021-08-02 16:05:01', '2021-08-02 16:05:01'),
(12, 1, 'zain', 'malik', 'demo@demo.com', 'znm', 'India', NULL, NULL, '2021-08-02 16:07:26', '2021-08-02 16:07:26'),
(13, 1, 'zain', 'malik', 'demo@demo.com', 'znm', 'India', NULL, NULL, '2021-08-02 16:08:32', '2021-08-02 16:08:32'),
(14, 1, 'Garth', 'Raymond', 'qorexyx@mailinator.com', 'Sellers and Benton Inc', 'India', NULL, NULL, '2021-08-02 16:31:27', '2021-08-02 16:31:27'),
(15, 1, 'zain', 'malik', 'demo@demo.com', 'jkkk', 'India', NULL, NULL, '2021-08-03 12:42:11', '2021-08-03 12:42:11'),
(16, 1, 'zain', 'malik', 'demo@demo.com', 'bbn', 'India', NULL, NULL, '2021-08-03 12:44:11', '2021-08-03 12:44:11'),
(17, 7, 'emad', 'akbar', 'emad@gmail.com', 'saas', 'India', NULL, NULL, '2021-08-08 09:28:30', '2021-08-08 09:28:30'),
(18, 7, 'emad', 'akbar', 'emad@gmail.com', 'saas', 'India', NULL, NULL, '2021-08-08 09:28:31', '2021-08-08 09:28:31'),
(19, 7, 'emad', 'akbar', 'emad@gmail.com', 'hh', 'India', NULL, NULL, '2021-08-08 09:29:20', '2021-08-08 09:29:20');

-- --------------------------------------------------------

--
-- Table structure for table `carts`
--

CREATE TABLE `carts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `quanity` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `carts`
--

INSERT INTO `carts` (`id`, `product_id`, `user_id`, `quanity`, `created_at`, `updated_at`) VALUES
(25, 1, 1, 1, '2021-08-03 12:41:46', '2021-08-03 12:41:46');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `is_deletd` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `status`, `is_deletd`, `created_at`, `updated_at`) VALUES
(1, 'Graphics', 'active', 0, NULL, NULL),
(2, 'UI Design', 'active', 0, NULL, '2021-08-10 15:04:55'),
(3, 'Web Design', 'active', 0, NULL, NULL),
(4, 'Fonts', 'active', 0, NULL, NULL),
(5, 'Programming', 'active', 0, '2021-08-10 13:35:03', '2021-08-10 13:35:03'),
(6, 'Brillenitcategory', 'active', 0, '2021-08-10 13:36:00', '2021-08-11 15:01:31'),
(7, 'Programming', 'active', 0, '2021-08-11 15:08:17', '2021-08-11 15:08:17');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comments`
--

INSERT INTO `comments` (`id`, `user_id`, `product_id`, `comment`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'This is dummy comment', '2021-08-02 20:39:11', NULL),
(2, 1, 1, 'This is an other comment here', '2021-08-06 15:05:48', '2021-08-06 15:05:48'),
(3, 1, 1, 'This is an other comment here', '2021-08-06 15:10:12', '2021-08-06 15:10:12'),
(4, 1, 1, 'This is an other comment here', '2021-08-06 15:11:01', '2021-08-06 15:11:01'),
(5, 7, 5, 'kkkss', '2021-08-08 09:30:42', '2021-08-08 09:30:42');

-- --------------------------------------------------------

--
-- Table structure for table `comment_replies`
--

CREATE TABLE `comment_replies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comment_replies`
--

INSERT INTO `comment_replies` (`id`, `user_id`, `comment_id`, `comment`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'this is reply commment', '2021-08-02 20:39:02', NULL),
(2, 7, 5, 'nice', '2021-08-08 09:44:17', '2021-08-08 09:44:17');

-- --------------------------------------------------------

--
-- Table structure for table `confirm_orders`
--

CREATE TABLE `confirm_orders` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `confirm_orders`
--

INSERT INTO `confirm_orders` (`id`, `user_id`, `product_id`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, '1,  4,  2,', 'pending', '2021-08-02 16:28:58', '2021-08-02 16:28:58'),
(2, 1, '1,  4,  2,', 'pending', '2021-08-02 16:31:37', '2021-08-02 16:31:37'),
(3, 1, '1,', 'pending', '2021-08-03 12:42:37', '2021-08-03 12:42:37'),
(4, 7, '4,', 'pending', '2021-08-08 09:29:40', '2021-08-08 09:29:40');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2021_07_30_200026_create_app_settings_table', 2),
(5, '2021_08_01_093421_create_categories_table', 3),
(6, '2021_08_01_092511_create_products_table', 4),
(7, '2021_08_01_094158_create_product_images_table', 5),
(8, '2021_08_01_122503_create_carts_table', 6),
(9, '2021_08_02_183127_create_billing_details_table', 7),
(11, '2021_08_02_185732_create_confirm_orders_table', 8),
(12, '2021_08_05_194451_create_comments_table', 9),
(13, '2021_08_05_200819_create_comment_replies_table', 10);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `category_id` bigint(20) UNSIGNED NOT NULL,
  `details` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `is_deletd` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `title`, `price`, `category_id`, `details`, `status`, `is_deletd`, `created_at`, `updated_at`) VALUES
(1, 'Floating Phone and Tablet Mockup (PSD)', '50', 1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor i', 'featured', 0, '2021-07-01 11:02:54', '2021-08-11 12:32:25'),
(2, 'Floating Phone and Tablet Mockup (PSD)', '5', 4, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor i', 'featured', 0, '2021-07-01 11:03:05', NULL),
(3, 'Floating Phone and Tablet Mockup (PSD)', '5', 2, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor i', 'featured', 0, '2021-07-01 11:03:09', NULL),
(4, 'Floating Phone and Tablet Mockup (PSD)', '785', 2, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor i', 'featured', 0, '2021-07-01 11:03:18', '2021-08-11 12:28:52'),
(5, 'Floating Phone and Tablet Mockup (PSD)', '785', 1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor i', 'active', 0, '2021-08-02 11:02:22', NULL),
(6, 'Floating Phone and Tablet Mockup (PSD)', '785', 4, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor i', 'active', 0, '2021-08-01 11:02:34', NULL),
(9, 'Floating Phone and Tablet Mockup (PSD)', '785', 1, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor i', 'active', 0, '2021-08-02 11:02:22', NULL),
(10, 'Floating Phone and Tablet Mockup (PSD)', '785', 4, 'Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor i', 'active', 0, '2021-08-01 11:02:34', NULL),
(11, 'sdlsadasldsal', '21', 1, 'asdkasdlkasdlkas', 'active', 0, '2021-08-11 12:03:16', '2021-08-11 12:03:16'),
(12, 'jjjs', '21', 1, 'ssadasdsa', 'active', 0, '2021-08-11 15:07:10', '2021-08-11 15:07:21');

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `product_image` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `product_images`
--

INSERT INTO `product_images` (`id`, `product_id`, `product_image`, `status`, `created_at`, `updated_at`) VALUES
(1, 1, '02.jpg', '', NULL, NULL),
(2, 2, '03.jpg', '', NULL, NULL),
(3, 3, '07.jpg', '', NULL, NULL),
(4, 4, '09.jpg', '', NULL, NULL),
(5, 5, '03.jpg', '', NULL, NULL),
(6, 6, '07.jpg', '', NULL, NULL),
(7, 9, '09.jpg', '', NULL, NULL),
(8, 10, '09.jpg', '', NULL, NULL),
(9, 1, '02.jpg', '', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `first_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `avatar` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(1000) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_num` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `avatar`, `email`, `type`, `phone_num`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'zain', 'malik', '', 'demo@demo.com', 'user', '', NULL, '$2y$10$U5zXSAl/8mh7Hko3ybD3wusg07yVt.SToO4OUdha2WajyMwaFXcK2', NULL, '2021-07-29 15:12:04', '2021-07-29 15:12:04'),
(2, 'zain', 'malik', 'avatar.png', 'zain1000@gmail.com', 'user', '778787', NULL, '$2y$10$9crknd.DoJRS1.wnZqEvm.voxkihZ34X1UhN6Ai5CDPreuecDtVA6', NULL, '2021-07-30 14:42:28', '2021-07-30 14:42:28'),
(3, 'zain', 'malik', 'avatar.png', 'client@client.com', 'user', '1221122122', NULL, '$2y$10$T0P6y4VVKzrf874nJsJhnu9ecRF/9aoehJ6KbYWrCEdaIdBbW8J.2', NULL, '2021-07-30 14:46:47', '2021-07-30 14:46:47'),
(4, 'zain', 'malik', 'avatar.png', 'sa@client.com', 'user', '455545', NULL, '$2y$10$g1Sd3ffQJpoVLZaops3g6OryQmioAOGXz4IsGVkbKRiJGC76Nnb1u', NULL, '2021-07-30 14:53:47', '2021-07-30 14:53:47'),
(5, 'zain', 'zainmalik', 'avatar.png', 'sa@client.comxx', 'user', '778\\87', NULL, '$2y$10$JTkYcsmX1./wZ84.fHJFxeiubshKdOHE.QbOBgd7RN0q7MTShzv9C', NULL, '2021-07-30 14:58:05', '2021-07-30 14:58:05'),
(6, 'zain', 'c,m', 'avatar.png', 'sa@client.comcxx', 'user', '1212122', NULL, '$2y$10$FD7.zY89Pqys0AN5e9PBAuzlyLNKl/q57ZXmByYYzOzaWjbuLAelK', NULL, '2021-07-30 14:59:26', '2021-07-30 14:59:26'),
(7, 'emad', 'akbar', 'avatar.png', 'emad@gmail.com', 'admin', '223232', NULL, '$2y$10$4tB2K5w3j8RtOEjgbs/o0eVlF1IcVPuoM0IbozEjUw5.xeO8aT7DK', NULL, '2021-08-08 09:27:59', '2021-08-08 09:27:59'),
(9, 'hassan', 'raza', 'avatar.png', 'hassan@gmail.com', 'user', '277722', NULL, '$2y$10$ODy1AHNEhc3FayzNwRPOCuS7BatfgA9aEC.SVXkk8zE7zx9cwFAYe', NULL, '2021-08-10 11:24:19', '2021-08-10 11:24:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `app_settings`
--
ALTER TABLE `app_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `billing_details`
--
ALTER TABLE `billing_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `billing_details_payer_id_foreign` (`payer_id`);

--
-- Indexes for table `carts`
--
ALTER TABLE `carts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `carts_product_id_foreign` (`product_id`),
  ADD KEY `carts_user_id_foreign` (`user_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_user_id_foreign` (`user_id`),
  ADD KEY `comments_product_id_foreign` (`product_id`);

--
-- Indexes for table `comment_replies`
--
ALTER TABLE `comment_replies`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comment_replies_user_id_foreign` (`user_id`),
  ADD KEY `comment_replies_comment_id_foreign` (`comment_id`);

--
-- Indexes for table `confirm_orders`
--
ALTER TABLE `confirm_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `confirm_orders_user_id_foreign` (`user_id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `products_category_id_foreign` (`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`id`),
  ADD KEY `product_images_product_id_foreign` (`product_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `app_settings`
--
ALTER TABLE `app_settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `billing_details`
--
ALTER TABLE `billing_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `carts`
--
ALTER TABLE `carts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `comment_replies`
--
ALTER TABLE `comment_replies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `confirm_orders`
--
ALTER TABLE `confirm_orders`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `billing_details`
--
ALTER TABLE `billing_details`
  ADD CONSTRAINT `billing_details_payer_id_foreign` FOREIGN KEY (`payer_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `carts`
--
ALTER TABLE `carts`
  ADD CONSTRAINT `carts_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `carts_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `comments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `comment_replies`
--
ALTER TABLE `comment_replies`
  ADD CONSTRAINT `comment_replies_comment_id_foreign` FOREIGN KEY (`comment_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `comment_replies_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `confirm_orders`
--
ALTER TABLE `confirm_orders`
  ADD CONSTRAINT `confirm_orders_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Constraints for table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`);

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
