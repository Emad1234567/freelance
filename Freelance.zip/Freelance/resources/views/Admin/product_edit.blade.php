@extends('layouts.admin')

@section('content')

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <section class="content-main">
        <div class="content-header">

        <div>
                    <h2 class="content-title card-title">Products Edit</h2>
                    <p>Lorem ipsum dolor sit amet.</p>
                </div>
                <div>
                    <!-- <input type="text" placeholder="Search order ID" class="form-control bg-white"> -->
                </div>
            </div>
</div>
            <div class="card mb-4">
                <header class="card-header">
                @if (session('msg'))
                        <span class="badge badge-primary">
                            {{ session('msg') }}
                        </span>
                    @endif
                    <div class="row gx-3">
                        <div class="col-lg-4 col-md-6 me-auto">
                            <!-- <input type="text" placeholder="Search..." class="form-control"> -->
                          
                        </div>
                        <div class="col-lg-2 col-6 col-md-3">
                            <select class="form-select">
                                <option>Status</option>
                                <option>Active</option>
                                <option>Disabled</option>
                                <option>Show all</option>
                            </select>
                        </div>
                        <div class="col-lg-2 col-6 col-md-3">
                            <select class="form-select">
                                <option>Show 20</option>
                                <option>Show 30</option>
                                <option>Show 40</option>
                            </select>
                        </div>
                    </div>
        <div class="card-body">
        <form method="post" action="/edit_product/{{$product->id}}">
				@csrf
                @php
                $category = App\Models\Category::get();
                @endphp
                <label>Product Tittle</label>
                <input type="text" placeholder="Type name here" value="{{$product->title}}" class="form-control" name="name" required>         
                <label>Price</label>
                <input type="text" placeholder="Type name here"  value="{{$product->price}}" class="form-control" name="price" required>
                <label>Category</label>
                <select name="category"  class="form-control" required>
                 <option value="">Select Category</option>
                 @foreach($category as $categorys)
                 <option value="{{$categorys->id}}" @if($categorys->id == $product->category_id) selected @endif>{{$categorys->name}}</option>
                  @endforeach             
                 </select>  
                 <label>Product Detail</label>
               <textarea name="detail" class="form-control" required>{{$product->details}}</textarea>
               <br>
               <br>
               <button type="submit" class="btn btn-primary">Edit Product</button>
     
      </form>
                </div> <!-- card-body end// -->
            </div>

            <!-- <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add new Product</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="post" action="/add_product">
				@csrf
                @php
                $category = App\Models\Category::get();
                @endphp
                <label>Product Tittle</label>
                <input type="text" placeholder="Type name here" class="form-control" name="name" required>         
                <label>Price</label>
                <input type="text" placeholder="Type name here" class="form-control" name="price" required>
                <label>Category</label>
                <select name="category"  class="form-control" required>
                 <option value="">Select Category</option>
                 @foreach($category as $categorys)
                 <option value="{{$categorys->id}}">{{$categorys->name}}</option>
                  @endforeach             
                 </select>  
                 <label>Product Detail</label>
               <textarea name="detail" class="form-control" required></textarea>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add Product</button>
      </div>
      </form>
    </div>
  </div>
</div> -->

<
        </section> <!-- content-main end// -->
       @endsection