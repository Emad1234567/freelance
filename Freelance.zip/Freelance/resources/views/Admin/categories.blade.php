@extends('layouts.admin')

@section('content')

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
        <section class="content-main">
        <div class="content-header">

        <div>
                    <h2 class="content-title card-title">Categories List</h2>
                    <p>Lorem ipsum dolor sit amet.</p>
                </div>
                <div>
                    <!-- <input type="text" placeholder="Search order ID" class="form-control bg-white"> -->
                </div>
            </div>
</div>
            <div class="card mb-4">
                <header class="card-header">
                @if (session('msg'))
                        <span class="badge badge-primary">
                            {{ session('msg') }}
                        </span>
                    @endif
                    <div class="row gx-3">
                        <div class="col-lg-4 col-md-6 me-auto">
                            <!-- <input type="text" placeholder="Search..." class="form-control"> -->
                            <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
 Add New Categorie
</button>
                        </div>
                        <div class="col-lg-2 col-6 col-md-3">
                            <select class="form-select">
                                <option>Status</option>
                                <option>Active</option>
                                <option>Disabled</option>
                                <option>Show all</option>
                            </select>
                        </div>
                        <div class="col-lg-2 col-6 col-md-3">
                            <select class="form-select">
                                <option>Show 20</option>
                                <option>Show 30</option>
                                <option>Show 40</option>
                            </select>
                        </div>
                    </div>
        <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th scope="col">Name</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Edit</th>
                                    <th scope="col">Delete</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($categorie as $categories)
                                <tr>
                                    <td>{{$categories->name}}</td>
                                    @if($categories->status == 'active')
                                    <td>Active</td>
                                    @else
                                    <td>Not Active</td>
                                    @endif
                                   
                                    <td><a href=" /Admin/Edit-Category/{{$categories->id}}" class="btn btn-primary">Edit</a></td>
                                    <td><a href="/delete_category/{{$categories->id}}" class="btn btn-danger">Delete</a></td>
                                </tr>
                            
                                 

                               @endforeach
                              
                          
                            </tbody>
                        </table>
                    </div> <!-- table-responsive //end -->
                </div> <!-- card-body end// -->
            </div>

            <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Add new Category</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      <form method="post" action="/add_category">
				@csrf
                <label>Category Name</label>
                <input type="text"  placeholder="Type name here" class="form-control" name="name">         

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-primary">Add Category</button>
      </div>
      </form>
    </div>
  </div>
</div>



        </section> <!-- content-main end// -->
       @endsection