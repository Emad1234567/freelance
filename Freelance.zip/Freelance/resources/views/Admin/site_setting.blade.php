@extends('layouts.admin')

@section('content')
<section class="content-main">
            <div class="content-header">
                <h2 class="content-title">Site settings </h2>
            </div>
            <div class="card">\
            @if (session('status'))
                        <span class="badge badge-primary">
                            {{ session('status') }}
                        </span>
                    @endif
                <div class="card-body">
                  
                       
                            <section class="content-body p-xl-4">
                                <form method="post" action="/Admin/app_setting?setting=website_name">
                                    @csrf
                                    <div class="row border-bottom mb-4 pb-4">
                                        <div class="col-md-5">
                                            <h5>Website name</h5>
                                            <br>
                                            
                                            <input class="form-control" type="text" value="{{$app_setting->app_name}}" name="website_name" placeholder="Type here">
                                             <br>
                                             <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                             <br>
                                             <br>
</form>        
<br>
<form method="post" action="/Admin/app_setting?setting=main_heading">
                                    @csrf
                                            <h5>Main Heading</h5>
                                            <br>
                                            
                                            <input class="form-control" type="text" value="{{$app_setting->app_main_heading}}" name="main_heading" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>        

<form method="post" action="/Admin/app_setting?setting=sub_heading">
                                    @csrf
                                            <h5>Sub Heading</h5>
                                            <br>
                                            
                                            <input class="form-control" type="text" value="{{$app_setting->app_sub_heading}}" name="sub_heading" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>       
                                        </div> <!-- col.// -->
                                        <div class="col-md-7">
                                            <div class="mb-3">
                                            <form method="post" action="/Admin/app_setting?setting=top_noti_1">
                                    @csrf       
                                            <h5>Top Notification 1</h5>
                                            <br>
                                            
                                            <input class="form-control" type="text" value="{{$app_setting->top_bar_noti1}}" name="top_noti_1" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>
<form method="post" action="/Admin/app_setting?setting=top_noti_2">
                                    @csrf       
                                            <h5>Top Notification 2</h5>
                                            <br>
                                            
                                            <input class="form-control" type="text" value="{{$app_setting->top_bar_noti2}}" name="top_noti_2" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>
                                            <br>
                                            <form method="post" action="/Admin/app_setting?setting=top_noti_3">
                                    @csrf       
                                            <h5>Top Notification 3</h5>
                                            <br>
                                            
                                            <input class="form-control" type="text" value="{{$app_setting->top_bar_noti3 }}" name="top_noti_3" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>
                                            </div>
                                        </div> <!-- col.// -->
                                    </div> <!-- row.// -->
                                    <div class="row border-bottom mb-4 pb-4">
                                      
                                         <center>
                                         <form method="post" enctype="multipart/form-data" action="/Admin/app_setting?setting=site_logo">
                                    @csrf    
                                                <h5 >Site Logo</h5>
                                                <br>
                                                <input type="file" class="form-control" name="logo_file"><br>
      <img src="{{asset('/site_logo')}}/{{$app_setting->app_logo}}"style="width:150px;">
      <p style="color:red;">*Only JPG,JPEG,PNG file supported</p>
</center>
<button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>    
                                    </div> <!-- row.// -->
                                    <div class="row border-bottom mb-4 pb-4">
                                    <center>
                                    <form method="post" action="/Admin/app_setting?setting=facebook">
                                    @csrf    
                                            <h5>Facebook</h5>
                                            <br>
                                            <input class="form-control" type="text" value="{{$app_setting->facebook }}" name="facebook" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>             
                                           
<form method="post" action="/Admin/app_setting?setting=twitter">
                                    @csrf    
                                            <h5>Twitter</h5>
                                            <br>
                                            <input class="form-control" type="text" value="{{$app_setting->twitter }}" name="twitter" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>             
<form method="post" action="/Admin/app_setting?setting=youtube">
                                    @csrf    
                                            <h5>Youtube</h5>
                                            <br>
                                            <input class="form-control" type="text" value="{{$app_setting->youtube }}" name="youtube" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>             
<form method="post" action="/Admin/app_setting?setting=instagram">
                                    @csrf    
                                            <h5>Instagram</h5>
                                            <br>
                                            <input class="form-control" type="text" value="{{$app_setting->insta}}" name="instagram" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>             
                                            <br>
                                            <form method="post" action="/Admin/app_setting?setting=linkdin">
                                    @csrf    
                                            <h5>LinkdIn</h5>
                                            <br>
                                            <input class="form-control" type="text" value="{{$app_setting->linkedin}}"  name="linkdin" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>             
</center>
                                    </div> <!-- row.// -->
                                   
                                   
                            </section> <!-- content-body .// -->
                        </div> <!-- col.// -->
                    </div> <!-- row.// -->
               
           
        </section> <!-- content-main end// -->
 @endsection       