@extends('layouts.app')

@section('content')
    <div class="container py-4 py-lg-5 my-4">
        <div class="row">
            <div class="col-md-6">
                <div class="card border-0 shadow">
                    <div class="card-body">
                        <h2 class="h4 mb-1">Sign in</h2>

                        <hr><br>
                        <form class="needs-validation" novalidate="" method="POST" action="{{ route('login') }}">
                            @csrf
                            <div class="input-group mb-3">
                                <i class="ci-mail position-absolute top-50 translate-middle-y text-muted fs-base ms-3"></i>
                                <input class="form-control rounded-start @error('email') is-invalid @enderror" name="email"
                                    value="{{ old('email') }}" type="email" placeholder="Email" required="">

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                            <div class="input-group mb-3"><i
                                    class="ci-locked position-absolute top-50 translate-middle-y text-muted fs-base ms-3"></i>
                                <div class="password-toggle w-100">
                                    <input class="form-control @error('password') is-invalid @enderror" name="password"
                                        required autocomplete="current-password" type="password" placeholder="Password">
                                    <label class="password-toggle-btn" aria-label="Show/hide password">
                                        <input class="password-toggle-check" type="checkbox"><span
                                            class="password-toggle-indicator"></span>
                                    </label>

                                    @error('password')
                                        <span class="invalid-feedback" role="alert">
                                            <strong>{{ $message }}</strong>
                                        </span>
                                    @enderror
                                </div>
                            </div>
                            <div class="d-flex flex-wrap justify-content-between">
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" {{ old('remember') ? 'checked' : '' }}
                                        id="remember_me">
                                    <label class="form-check-label" for="remember_me">Remember me</label>
                                </div><a class="nav-link-inline fs-sm" href="{{ route('password.request') }}">Forgot
                                    password?</a>
                            </div>
                            <hr class="mt-4">
                            <div class="text-end pt-4">
                                <button class="btn btn-primary" type="submit"><i class="ci-sign-in me-2 ms-n21"></i>Sign
                                    In</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6 pt-4 mt-3 mt-md-0">
                <h2 class="h4 mb-3">No account? Sign up</h2>
                <p class="fs-sm text-muted mb-4">Registration takes less than a minute but gives you full control over your
                    orders.</p>
                <form class="needs-validation" method="POST" action="{{ route('register') }}" novalidate="">
                    @csrf
                    <div class="row gx-4 gy-3">
                        <div class="col-sm-6">
                            <label class="form-label" for="reg-fn">First Name</label>
                            <input class="form-control @error('first_name') is-invalid @enderror" type="text" required=""
                                id="reg-fn" name="first_name" value="{{ old('first_name') }}">
                            <div class="invalid-feedback">Please enter your first name!</div>
                            @error('name')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-sm-6">
                            <label class="form-label" for="reg-ln">Last Name</label>
                            <input class="form-control" name="last_name" type="text" required="" id="reg-ln">
                            <div class="invalid-feedback">Please enter your last name!</div>
                        </div>
                        <div class="col-sm-6">
                            <label class="form-label" for="reg-email">E-mail Address</label>
                            <input class="form-control @error('email') is-invalid @enderror" type="email" required=""
                                id="reg-email" name="email" value="{{ old('email') }}">
                            <div class="invalid-feedback">Please enter valid email address!</div>
                            @error('email')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-sm-6">
                            <label class="form-label" for="reg-phone">Phone Number</label>
                            <input class="form-control @error('phone_num') is-invalid @enderror" type="text"
                                name="phone_num" required="" id="reg-phone">
                            <div class="invalid-feedback">Please enter your phone number!</div>
                        </div>
                        <div class="col-sm-6">
                            <label class="form-label" for="reg-password">Password</label>
                            <input class="form-control @error('password') is-invalid @enderror" type="password" required=""
                                id="reg-password" name="password">
                            <div class="invalid-feedback">Please enter password!</div>
                            @error('password')
                                <span class="invalid-feedback" role="alert">
                                    <strong>{{ $message }}</strong>
                                </span>
                            @enderror
                        </div>
                        <div class="col-sm-6">
                            <label class="form-label" for="reg-password-confirm">Confirm Password</label>
                            <input class="form-control" type="password" required="" name="password_confirmation"
                                id="reg-password-confirm">
                            <div class="invalid-feedback">Passwords do not match!</div>
                        </div>
                        <div class="col-12 text-end">
                            <button class="btn btn-primary" type="submit"><i class="ci-user me-2 ms-n1"></i>Sign Up</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
@endsection
