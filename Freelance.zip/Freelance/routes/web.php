<?php

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return redirect('home');
});


Auth::routes(['verify' => true]);


Route::get('/email/verify', function () {
    return view('auth.verify-email');
})->middleware('auth')->name('verification.notice');


Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
Route::get('/remove_product_from_cart/{id}', [App\Http\Controllers\HomeController::class, 'remove_product_from_cart'])->name('remove_product_from_cart/{id}');
Route::get('/Cart', [App\Http\Controllers\HomeController::class, 'cart'])->name('Cart');
Route::get('/add_to_cart_from_front/{id}', [App\Http\Controllers\HomeController::class, 'add_to_cart_from_front'])->name('add_to_cart_from_front/{id}');
Route::get('/Checkout', [App\Http\Controllers\HomeController::class, 'checkout'])->name('/Checkout');
Route::post('/save_billing_details', [App\Http\Controllers\HomeController::class, 'save_billing_details'])->name('/save_billing_details');
Route::post('/order_confirm', [App\Http\Controllers\HomeController::class, 'order_confirm'])->name('/order_confirm');
Route::get('/Thnak-you', [App\Http\Controllers\HomeController::class, 'thankyou'])->name('/Thnak-you');
Route::get('/Search-Product', [App\Http\Controllers\HomeController::class, 'search_product'])->name('/Search-Product');
Route::get('/Product-Details/{id}/{name}', [App\Http\Controllers\HomeController::class, 'product_details'])->name('/Product-Details/{id}/{name}');
Route::post('/post_comment/{id}', [App\Http\Controllers\HomeController::class, 'post_comment'])->name('/post_comment/{id}');
Route::post('/post_reply/{id}', [App\Http\Controllers\HomeController::class, 'post_reply'])->name('/post_reply/{id}');

Route::get('/Admin/Dashboard', function () {
    return view('/Admin/Dashboard');
});

Route::get('/Admin/Categories' , [App\Http\Controllers\AdminController::class, 'catagories'] )->name('/Admin/Categories');
Route::post('/add_category' , [App\Http\Controllers\AdminController::class, 'add_category'] )->name('/add_category');
Route::post('/edit_category/{id}' ,[App\Http\Controllers\AdminController::class, 'edit_category'])->name('/edit_category/{id}');
Route::get('/delete_category/{id}' ,[App\Http\Controllers\AdminController::class, 'delete_category'])->name('/delete_category/{id}');
Route::get('/Admin/Products' ,[App\Http\Controllers\AdminController::class, 'product_view'])->name('/Admin/Products');
Route::post('/add_product' ,[App\Http\Controllers\AdminController::class, 'add_product'])->name('/add_product');
Route::get('/Admin/Product-Edit/{id}' ,[App\Http\Controllers\AdminController::class, 'edit_produt_view'])->name('/Admin/Product-Edit/{id}');
Route::post('/edit_product/{id}' ,[App\Http\Controllers\AdminController::class, 'edit_product'])->name('/edit_product/{id}');
Route::get('/product_delete/{id}' ,[App\Http\Controllers\AdminController::class, 'product_delete'])->name('/product_delete/{id}');
Route::get('/Admin/Site-Setting' ,[App\Http\Controllers\AdminController::class, 'site_setting_view'])->name('/Admin/Site-Setting');
Route::post('/Admin/app_setting' ,[App\Http\Controllers\AdminController::class, 'save_site_setting'])->name('/Admin/app_setting');
Route::get('/Admin/Edit-Category/{id}' ,[App\Http\Controllers\AdminController::class, 'edit_category_view'])->name('/Admin/Edit-Categrie/{id}');





