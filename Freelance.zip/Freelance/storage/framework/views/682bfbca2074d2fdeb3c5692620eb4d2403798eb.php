<?php $__env->startSection('content'); ?>

    <div class="bg-accent pt-4 pb-5">
        <div class="container pt-2 pb-3 pt-lg-3 pb-lg-4">
            <div class="d-lg-flex justify-content-between pb-3">
                <div class="order-lg-2 mb-3 mb-lg-0 pt-lg-2">
                    <nav aria-label="breadcrumb">
                        <ol
                            class="breadcrumb breadcrumb-light flex-lg-nowrap justify-content-center justify-content-lg-start">
                            <li class="breadcrumb-item"><a class="text-nowrap" href="index.html"><i
                                        class="ci-home"></i>Home</a></li>
                            <li class="breadcrumb-item text-nowrap"><a href="home-marketplace.html">Market</a>
                            </li>
                            <li class="breadcrumb-item text-nowrap active" aria-current="page">Inside category</li>
                        </ol>
                    </nav>
                </div>
                <div class="order-lg-1 pe-lg-4 text-center text-lg-start">
                    <h1 class="h3 text-light mb-0">Marketplace category</h1>
                </div>
            </div>
        </div>
    </div>

    <div class="container pb-5 mb-2 mb-md-4">
        <!-- Toolbar-->
        <div class="bg-light shadow-lg rounded-3 mt-n5 mb-4">
            <div class="d-flex align-items-center ps-2">
                <!-- Search-->
                <form action="/Search-Product" class="col-sm-12" method="get">

                    <div class="input-group"><i
                            class="ci-search position-absolute top-50 start-0 translate-middle-y fs-md ms-3"></i>
                        <input class="form-control border-0 shadow-none" type="text" name="q" value="<?php echo e($query); ?>"
                            placeholder="Search in this category...">
                    </div>
                </form>

            </div><br>
            <!-- Products grid-->
            <div class="row pt-3 mx-n2">
                <?php if($product_count > 0): ?>
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!-- Product-->
                        <div class="col-lg-3 col-md-4 col-sm-6 px-2 mb-grid-gutter">
                            <div class="card product-card-alt">
                                <div class="product-thumb">

                                    <div class="product-card-actions">
                                        <a class="btn btn-light btn-icon btn-shadow fs-base mx-2"
                                            href="marketplace-single.html">
                                            <i class="ci-eye"></i>
                                        </a>
                                        <?php if(!Auth::check()): ?>

                                            <a href="#signin-modal" class="btn btn-light btn-icon btn-shadow fs-base mx-2"
                                                type="button" data-bs-toggle="modal">
                                                <i class="ci-cart"></i>
                                            </a>

                                        <?php else: ?>
                                            <a href="/add_to_cart_from_front/<?php echo e($products->id); ?>"
                                                class="btn btn-light btn-icon btn-shadow fs-base mx-2" type="button">
                                                <i class="ci-cart"></i>
                                            </a>
                                        <?php endif; ?>
                                    </div><a class="product-thumb-overlay" href="marketplace-single.html"></a>
                                    <img src="<?php echo e(asset('/front/img/marketplace/products')); ?>/<?php echo e($products->product_thumbnail()->product_image); ?>"
                                        alt="Product">
                                </div>
                                <div class="card-body">
                                    <div class="d-flex flex-wrap justify-content-between align-items-start pb-2">
                                        <div class="text-muted fs-xs me-1">
                                            <a class="product-meta fw-medium" href="#"><?php echo e($products->category->name); ?></a>
                                        </div>
                                        <div class="star-rating"><i class="star-rating-icon ci-star-filled active"></i><i
                                                class="star-rating-icon ci-star-filled active"></i><i
                                                class="star-rating-icon ci-star-filled active"></i><i
                                                class="star-rating-icon ci-star-filled active"></i><i
                                                class="star-rating-icon ci-star-filled active"></i>
                                        </div>
                                    </div>
                                    <h3 class="product-title fs-sm mb-2">
                                        <a href="marketplace-single.html">
                                            <?php echo e($products->title); ?>

                                        </a>
                                    </h3>
                                    <div class="d-flex flex-wrap justify-content-between align-items-center">
                                        <div class="fs-sm me-2"><i class="ci-download text-muted me-1"></i>109<span
                                                class="fs-xs ms-1">Sales</span></div>
                                        <div class="bg-faded-accent text-accent rounded-1 py-1 px-2">
                                            INT.<?php echo e($products->price); ?>.<small>00</small>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Product-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>

                    <div class="d-sm-flex justify-content-between align-items-center my-2 pb-3 border-bottom">
                        <div class="row">
                            <div class="container col-sm-2">
                                <img src="https://image.flaticon.com/icons/png/512/817/817954.png" alt="" srcset=""
                                    style="height: 8rem;">
                            </div>
                            <div class="container col-sm-6">
                                <h1>We are sorry we couldn't find product accordingly your search.</h1>
                                <p class="text-info">Tips</p>
                                <ul>
                                    <li>Try to search using different keyword.</li>
                                    <li>Go to home page and take a look our displayed products.</li>
                                    <li>Contact us and let us know what kind of product you are trying to looking for.</li>

                                </ul>
                            </div><br>
                            <a class="btn btn-outline-primary btn-sm ps-2" href="/home">
                                <i class="ci-home me-2"></i>
                                Go to home
                            </a>
                        </div>
                    </div>
                <?php endif; ?>
                <?php if($product_count > 0): ?>
                    <hr class="my-3">
                    <!-- Pagination-->
                    <?php echo e($product->links()); ?>

                <?php endif; ?>
            </div>

        <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\program files\Freelance\resources\views/search_result.blade.php ENDPATH**/ ?>