<?php $__env->startSection('content'); ?>
<?php
$app_setting = App\Models\AppSetting::first();
?>
    <section class="bg-accent bg-position-top-center bg-repeat-0 py-5"
        style="background-image: url(<?php echo e(asset('/front/img/home/marketplace-hero.jpg')); ?>);">
        <div class="pb-lg-5 mb-lg-3">
            <div class="container py-lg-5 my-lg-5">
                <div class="row mb-4 mb-sm-5">
                    <div class="col-lg-7 col-md-9 text-center text-sm-start">
                        <h1 class="text-white lh-base"><span class='fw-light'><?php echo e($app_setting->app_main_heading); ?></h1>
                        <h2 class="h5 text-white fw-light"><?php echo e($app_setting->app_sub_heading); ?></h2>
                    </div>
                </div>
                <div class="row pb-lg-5 mb-4 mb-sm-5">
                    <div class="col-lg-6 col-md-8">
                        <form action="/Search-Product" method="get">

                            <div class="input-group input-group-lg flex-nowrap">
                                <i class="ci-search position-absolute top-50 translate-middle-y ms-3"></i>
                                <input class="form-control rounded-start" type="text" name="q"
                                    placeholder="Start your search">
                                <button class="btn btn-primary" type="button">
                                    <i class="navbar-tool-icon ci-search"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        </div>
    </section>
    <?php if($featured_count > 0): ?>
        <!-- Featured products (Carousel)-->
        <section class="container position-relative pt-3 pt-lg-0 pb-5 mt-lg-n10" style="z-index: 10;">
            <div class="card px-lg-2 border-0 shadow-lg">
                <div class="card-body px-4 pt-5 pb-4">
                    <h2 class="h3 text-center">Discover featured products</h2>
                    <p class="text-muted text-center">Every week we hand-pick some of the best items from our collection</p>
                    <!-- Carousel-->
                    <div class="tns-carousel pt-4">
                        <div class="tns-carousel-inner"
                            data-carousel-options="{&quot;items&quot;: 2, &quot;gutter&quot;: 15, &quot;controls&quot;: false, &quot;nav&quot;: true, &quot;responsive&quot;: {&quot;0&quot;:{&quot;items&quot;:1},&quot;500&quot;:{&quot;items&quot;:2},&quot;768&quot;:{&quot;items&quot;:3}, &quot;992&quot;:{&quot;items&quot;:3, &quot;gutter&quot;: 30}}}">
                            <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $features): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- Product-->
                                <div>
                                    <div class="card product-card-alt">
                                        <div class="product-thumb">
                                            <div class="product-card-actions">
                                                <a class="btn btn-light btn-icon btn-shadow fs-base mx-2"
                                                    href="/Product-Details/<?php echo e($features->id); ?>/<?php echo e(str_replace(' ', '-', $features->title)); ?>">
                                                    <i class="ci-eye"></i>
                                                </a>
                                                <?php if(!Auth::check()): ?>

                                                    <a href="#signin-modal"
                                                        class="btn btn-light btn-icon btn-shadow fs-base mx-2" type="button"
                                                        data-bs-toggle="modal">
                                                        <i class="ci-cart"></i>
                                                    </a>

                                                <?php else: ?>
                                                    <a href="/add_to_cart_from_front/<?php echo e($features->id); ?>"
                                                        class="btn btn-light btn-icon btn-shadow fs-base mx-2"
                                                        type="button">
                                                        <i class="ci-cart"></i>
                                                    </a>
                                                <?php endif; ?>
                                            </div>
                                            <a class="product-thumb-overlay"
                                                href="/Product-Details/<?php echo e($features->id); ?>/<?php echo e(str_replace(' ', '-', $features->title)); ?>"></a>
                                            <img src="<?php echo e(asset('/front/img/marketplace/products')); ?>/<?php echo e($features->product_thumbnail()->product_image); ?>"
                                                alt="<?php echo e($features->title); ?>">
                                        </div>
                                        <div class="card-body">
                                            <div class="d-flex flex-wrap justify-content-between align-items-start pb-2">
                                                <div class="text-muted fs-xs me-1">

                                                    <a class="product-meta fw-medium" href="#"><i class="ci-tag"></i>
                                                        <?php echo e($features->category->name); ?></a>
                                                </div>
                                                <div class="star-rating"><i
                                                        class="star-rating-icon ci-star-filled active"></i><i
                                                        class="star-rating-icon ci-star-filled active"></i><i
                                                        class="star-rating-icon ci-star-filled active"></i><i
                                                        class="star-rating-icon ci-star-filled active"></i><i
                                                        class="star-rating-icon ci-star-filled active"></i>
                                                </div>
                                            </div>
                                            <h3 class="product-title fs-sm mb-2">
                                                <a
                                                    href="/Product-Details/<?php echo e($features->id); ?>/<?php echo e(str_replace(' ', '-', $features->title)); ?>">
                                                    <?php echo e($features->title); ?>

                                                </a>
                                            </h3>
                                            <div class="d-flex flex-wrap justify-content-between align-items-center">
                                                <div class="fs-sm me-2"><i class="ci-download text-muted me-1"></i>
                                                    109
                                                    <span class="fs-xs ms-1">Sales</span>
                                                </div>
                                                <div class="bg-faded-accent text-accent rounded-1 py-1 px-2">
                                                    INR. <?php echo e($features->price); ?>.<small>00</small>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- Product-->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            <?php if($featured_count > 6): ?>
                                <!-- More button-->
                                <div class="text-center">
                                    <a class="btn btn-outline-accent" href="marketplace-category.html">
                                        View more products<i class="ci-arrow-right fs-ms ms-1"></i>
                                    </a>
                                </div>
                            <?php endif; ?>
        </section>
    <?php endif; ?>


    <?php if($recent_release_count > 0): ?>


        
        <section class="container pb-5 mb-lg-3">
            <!-- Heading-->
            <div class="d-flex flex-wrap justify-content-between align-items-center pt-1 border-bottom pb-4 mb-4">
                <h2 class="h3 mb-0 pt-3 me-2">The most recent releases</h2>
            </div>
            <!-- Grid-->
            <div class="row pt-2 mx-n2">
                <?php $__currentLoopData = $recent_release; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent_releases): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <!-- Product-->
                    <div class="col-lg-3 col-md-4 col-sm-6 px-2 mb-grid-gutter">
                        <div class="card product-card-alt">
                            <div class="product-thumb">

                                <div class="product-card-actions">
                                    <a class="btn btn-light btn-icon btn-shadow fs-base mx-2"
                                        href="/Product-Details/<?php echo e($recent_releases->id); ?>/<?php echo e(str_replace(' ', '-', $recent_releases->title)); ?>">
                                        <i class="ci-eye"></i>
                                    </a>
                                    <?php if(!Auth::check()): ?>
                                        <a href="#signin-modal" class="btn btn-light btn-icon btn-shadow fs-base mx-2"
                                            type="button" data-bs-toggle="modal">
                                            <i class="ci-cart"></i>
                                        </a>
                                    <?php else: ?>
                                        <a href="/add_to_cart_from_front/<?php echo e($features->id); ?>"
                                            class="btn btn-light btn-icon btn-shadow fs-base mx-2" type="button">
                                            <i class="ci-cart"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                                <a class="product-thumb-overlay"
                                    href="/Product-Details/<?php echo e($recent_releases->id); ?>/<?php echo e(str_replace(' ', '-', $recent_releases->title)); ?>"></a>
                                <img src="<?php echo e(asset('/front/img/marketplace/products')); ?>/<?php echo e($features->product_thumbnail()->product_image); ?>"
                                    alt=" <?php echo e($recent_releases->title); ?>">
                            </div>
                            <div class="card-body">
                                <div class="d-flex flex-wrap justify-content-between align-items-start pb-2">
                                    <div class="text-muted fs-xs me-1"><i class="ci-tag"></i>
                                        <?php echo e($recent_releases->category->name); ?></div>
                                    <div class="star-rating">
                                        <i class="star-rating-icon ci-star-filled active"></i><i
                                            class="star-rating-icon ci-star-filled active"></i><i
                                            class="star-rating-icon ci-star-filled active"></i><i
                                            class="star-rating-icon ci-star-half active"></i><i
                                            class="star-rating-icon ci-star"></i>
                                    </div>
                                </div>
                                <h3 class="product-title fs-sm mb-2">
                                    <a
                                        href="/Product-Details/<?php echo e($recent_releases->id); ?>/<?php echo e(str_replace(' ', '-', $recent_releases->title)); ?>">
                                        <?php echo e($recent_releases->title); ?>

                                    </a>
                                </h3>
                                <div class="d-flex flex-wrap justify-content-between align-items-center">
                                    <div class="fs-sm me-2">
                                        <i class="ci-download text-muted me-1"></i>153<span class="fs-xs ms-1">Sales</span>
                                    </div>
                                    <div class="bg-faded-accent text-accent rounded-1 py-1 px-2">INR
                                        <?php echo e($recent_releases->price); ?>.<small>00</small></div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Product-->

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php if($recent_release_count > 8): ?>
                <!-- More button-->
                <div class="text-center">
                    <a class="btn btn-outline-accent" href="marketplace-category.html">View more products
                        <i class="ci-arrow-right fs-ms ms-1"></i>
                    </a>
                </div>

            <?php endif; ?>
        </section>
    <?php endif; ?>

    <!-- Best Selling of the month-->
    <section class="border-top py-5">
        <div class="container py-lg-2">
            <h2 class="h3 mb-3 pb-3 pb-lg-4 text-center text-lg-start">Best Selling of the month</h2>
            <div class="row">
                <div class="col-lg-4 text-center text-lg-start pb-3 pt-lg-2">
                    <div class="d-inline-block text-start">
                        <div class="d-flex align-items-center pb-3">
                            <div class="img-thumbnail rounded-circle flex-shrink-0" style="width: 6.375rem;"><img
                                    class="rounded-circle" src="<?php echo e(asset('front/img/marketplace/account/avatar.png')); ?>"
                                    alt="Createx Studio">
                            </div>
                            <div class="ps-3">
                                <h3 class="fs-lg mb-0">Createx Studio</h3><span
                                    class="d-block text-muted fs-ms pt-1 pb-2">Member since November 2019</span><a
                                    class="btn btn-primary btn-sm" href="marketplace-vendor.html">View products</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-8">
                    <div class="tns-carousel">
                        <div class="tns-carousel-inner"
                            data-carousel-options="{&quot;items&quot;: 2, &quot;gutter&quot;: 16, &quot;controls&quot;: false, &quot;nav&quot;: true, &quot;responsive&quot;: {&quot;0&quot;:{&quot;items&quot;:1},&quot;500&quot;:{&quot;items&quot;:2},&quot;768&quot;:{&quot;items&quot;:3}}}">
                            <div>
                                <div class="card product-card-alt">
                                    <div class="product-thumb">

                                        <div class="product-card-actions"><a
                                                class="btn btn-light btn-icon btn-shadow fs-base mx-2"
                                                href="marketplace-single.html"><i class="ci-eye"></i></a>
                                            <button class="btn btn-light btn-icon btn-shadow fs-base mx-2" type="button"><i
                                                    class="ci-cart"></i></button>
                                        </div><a class="product-thumb-overlay" href="marketplace-single.html"></a><img
                                            src="<?php echo e(asset('front/img/marketplace/products/13.jpg')); ?>" alt="Product">
                                    </div>
                                    <div class="card-body">
                                        <h3 class="product-title fs-sm mb-2"><a href="marketplace-single.html">Hardcover
                                                Book Catalog Mockup</a></h3>
                                        <div class="d-flex flex-wrap justify-content-between align-items-center">
                                            <div class="fs-sm me-2"><i class="ci-download text-muted me-1"></i>39<span
                                                    class="fs-xs ms-1">Sales</span></div>
                                            <div class="bg-faded-accent text-accent rounded-1 py-1 px-2">
                                                $12.<small>00</small></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="card product-card-alt">
                                    <div class="product-thumb">

                                        <div class="product-card-actions"><a
                                                class="btn btn-light btn-icon btn-shadow fs-base mx-2"
                                                href="marketplace-single.html"><i class="ci-eye"></i></a>
                                            <button class="btn btn-light btn-icon btn-shadow fs-base mx-2" type="button"><i
                                                    class="ci-cart"></i></button>
                                        </div><a class="product-thumb-overlay" href="marketplace-single.html"></a><img
                                            src="<?php echo e(asset('front/img/marketplace/products/14.jpg')); ?>" alt="Product">
                                    </div>
                                    <div class="card-body">
                                        <h3 class="product-title fs-sm mb-2"><a href="marketplace-single.html">Top View
                                                Smartwatch 3D Render</a></h3>
                                        <div class="d-flex flex-wrap justify-content-between align-items-center">
                                            <div class="fs-sm me-2"><i class="ci-download text-muted me-1"></i>28<span
                                                    class="fs-xs ms-1">Sales</span></div>
                                            <div class="bg-faded-accent text-accent rounded-1 py-1 px-2">
                                                $14.<small>00</small></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div>
                                <div class="card product-card-alt">
                                    <div class="product-thumb">

                                        <div class="product-card-actions"><a
                                                class="btn btn-light btn-icon btn-shadow fs-base mx-2"
                                                href="marketplace-single.html"><i class="ci-eye"></i></a>
                                            <button class="btn btn-light btn-icon btn-shadow fs-base mx-2" type="button"><i
                                                    class="ci-cart"></i></button>
                                        </div><a class="product-thumb-overlay" href="marketplace-single.html"></a><img
                                            src="<?php echo e(asset('front/img/marketplace/products/07.jpg')); ?>" alt="Product">
                                    </div>
                                    <div class="card-body">
                                        <h3 class="product-title fs-sm mb-2"><a href="marketplace-single.html">Gravity
                                                Device Mockups (PSD)</a></h3>
                                        <div class="d-flex flex-wrap justify-content-between align-items-center">
                                            <div class="fs-sm me-2"><i class="ci-download text-muted me-1"></i>234<span
                                                    class="fs-xs ms-1">Sales</span></div>
                                            <div class="bg-faded-accent text-accent rounded-1 py-1 px-2">
                                                $16.<small>00</small></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Marketplace features-->
    <section class="bg-accent bg-size-cover bg-position-center pt-5 pb-4 pb-lg-5"
        style="background-image: url(img/marketplace/features/features-bg.jpg);">
        <div class="container pt-lg-3">
            <h2 class="h3 mb-3 pb-4 text-light text-center">Why our marketplace?</h2>
            <div class="row pt-lg-2 text-center">
                <div class="col-lg-3 col-sm-6 mb-grid-gutter">
                    <div class="d-inline-flex align-items-center text-start">
                        <img src="<?php echo e(asset('front/img/marketplace/features/quality.png')); ?>" width="52"
                            alt="Quality Guarantee">
                        <div class="ps-3">
                            <h6 class="text-light fs-base mb-1">Quality Guarantee</h6>
                            <p class="text-light fs-ms opacity-70 mb-0">Quality checked by our team</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 mb-grid-gutter">
                    <div class="d-inline-flex align-items-center text-start">
                        <img src="<?php echo e(asset('front/img/marketplace/features/support.png')); ?>" width="52"
                            alt="Customer Support">
                        <div class="ps-3">
                            <h6 class="text-light fs-base mb-1">Customer Support</h6>
                            <p class="text-light fs-ms opacity-70 mb-0">Friendly 24/7 customer support</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 mb-grid-gutter">
                    <div class="d-inline-flex align-items-center text-start">
                        <img src="<?php echo e(asset('front/img/marketplace/features/updates.png')); ?>" width="52"
                            alt="Free Updates">
                        <div class="ps-3">
                            <h6 class="text-light fs-base mb-1">Lifetime Free Updates</h6>
                            <p class="text-light fs-ms opacity-70 mb-0">Never pay for an update</p>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-sm-6 mb-grid-gutter">
                    <div class="d-inline-flex align-items-center text-start">
                        <img src="<?php echo e(asset('front/img/marketplace/features/secure.png')); ?>" width="52"
                            alt="Secure Payments">
                        <div class="ps-3">
                            <h6 class="text-light fs-base mb-1">Secure Payments</h6>
                            <p class="text-light fs-ms opacity-70 mb-0">We posess SSL / Secure сertificate</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Blog posts carousel-->
    <section class="py-5">
        <div class="container py-lg-3">
            <h2 class="h3 text-center">From the blog</h2>
            <p class="text-muted text-center mb-3 pb-4">Latest marketplace news, success stories and tutorials</p>
            <div class="tns-carousel">
                <div class="tns-carousel-inner"
                    data-carousel-options="{&quot;items&quot;: 2, &quot;gutter&quot;: 15, &quot;controls&quot;: false, &quot;nav&quot;: true, &quot;responsive&quot;: {&quot;0&quot;:{&quot;items&quot;:1},&quot;500&quot;:{&quot;items&quot;:2},&quot;768&quot;:{&quot;items&quot;:3}, &quot;992&quot;:{&quot;items&quot;:3, &quot;gutter&quot;: 30}}}">
                    <div>
                        <div class="card"><a class="blog-entry-thumb" href="blog-single.html"><img class="card-img-top"
                                    src="<?php echo e(asset('front/img/blog/05.jpg')); ?>" alt="Post"></a>
                            <div class="card-body">
                                <h2 class="h6 blog-entry-title"><a href="blog-single.html">We start selling WordPress themes
                                        soon</a></h2>
                                <p class="fs-sm">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                    tempor incididunt ut labore et dolore magna aliqua enim ad minim...</p>
                                <div class="fs-xs text-nowrap"><a class="blog-entry-meta-link text-nowrap" href="#">Nov
                                        23</a><span class="blog-entry-meta-divider mx-2"></span><a
                                        class="blog-entry-meta-link text-nowrap" href="blog-single.html#comments"><i
                                            class="ci-message"></i>19</a></div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="card"><a class="blog-entry-thumb" href="blog-single.html"><img class="card-img-top"
                                    src="<?php echo e(asset('front/img/blog/06.jpg')); ?>" alt="Post"></a>
                            <div class="card-body">
                                <h2 class="h6 blog-entry-title"><a href="blog-single.html">Shoot like a pro. Tips &amp;
                                        tricks</a></h2>
                                <p class="fs-sm">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                    tempor incididunt ut labore et dolore magna aliqua enim ad minim...</p>
                                <div class="fs-xs text-nowrap"><a class="blog-entry-meta-link text-nowrap" href="#">Oct
                                        10</a><span class="blog-entry-meta-divider mx-2"></span><a
                                        class="blog-entry-meta-link text-nowrap" href="blog-single.html#comments"><i
                                            class="ci-message"></i>28</a></div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="card"><a class="blog-entry-thumb" href="blog-single.html"><img class="card-img-top"
                                    src="<?php echo e(asset('front/img/blog/07.jpg')); ?>" alt="Post"></a>
                            <div class="card-body">
                                <h2 class="h6 blog-entry-title"><a href="blog-single.html">Designing engaging mobile
                                        experiences</a></h2>
                                <p class="fs-sm">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod
                                    tempor incididunt ut labore et dolore magna aliqua enim ad minim...</p>
                                <div class="fs-xs text-nowrap"><a class="blog-entry-meta-link text-nowrap" href="#">Sep
                                        15</a><span class="blog-entry-meta-divider mx-2"></span><a
                                        class="blog-entry-meta-link text-nowrap" href="blog-single.html#comments"><i
                                            class="ci-message"></i>46</a></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- More button-->
            <div class="text-center pt-4 mt-md-2"><a class="btn btn-outline-accent" href="blog-grid-sidebar.html">Ream more
                    posts<i class="ci-arrow-right fs-ms ms-1"></i></a></div>
        </div>
    </section>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\my project\Freelance\Freelance\resources\views/home.blade.php ENDPATH**/ ?>