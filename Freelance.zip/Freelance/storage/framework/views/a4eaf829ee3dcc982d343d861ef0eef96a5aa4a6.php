<?php $__env->startSection('content'); ?>


    <div class="page-title-overlap bg-accent pt-4">
        <div class="container d-lg-flex justify-content-between py-2 py-lg-3">

            <div class="order-lg-1 pe-lg-4 text-center text-lg-start">
                <h1 class="h3 text-light mb-0">Thanks for choosing us! </h1>
            </div>

            <div class="order-lg-2 mb-3 mb-lg-0 pt-lg-2">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb breadcrumb-light flex-lg-nowrap justify-content-center justify-content-lg-start">
                        <a class="btn btn-outline-primary btn-sm ps-2" href="/home">
                            <i class="ci-arrow-left me-2"></i>
                            Continue shopping
                        </a>
                    </ol>
                </nav>
            </div>
        </div>
    </div>

    <br>
    <br>
    <br>
    <br>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\program files\Freelance\resources\views/thankyou.blade.php ENDPATH**/ ?>