

<?php $__env->startSection('content'); ?>
<section class="content-main">
            <div class="content-header">
                <h2 class="content-title">Site settings </h2>
            </div>
            <div class="card">\
            <?php if(session('status')): ?>
                        <span class="badge badge-primary">
                            <?php echo e(session('status')); ?>

                        </span>
                    <?php endif; ?>
                <div class="card-body">
                  
                       
                            <section class="content-body p-xl-4">
                                <form method="post" action="/Admin/app_setting?setting=website_name">
                                    <?php echo csrf_field(); ?>
                                    <div class="row border-bottom mb-4 pb-4">
                                        <div class="col-md-5">
                                            <h5>Website name</h5>
                                            <br>
                                            
                                            <input class="form-control" type="text" value="<?php echo e($app_setting->app_name); ?>" name="website_name" placeholder="Type here">
                                             <br>
                                             <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                             <br>
                                             <br>
</form>        
<br>
<form method="post" action="/Admin/app_setting?setting=main_heading">
                                    <?php echo csrf_field(); ?>
                                            <h5>Main Heading</h5>
                                            <br>
                                            
                                            <input class="form-control" type="text" value="<?php echo e($app_setting->app_main_heading); ?>" name="main_heading" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>        

<form method="post" action="/Admin/app_setting?setting=sub_heading">
                                    <?php echo csrf_field(); ?>
                                            <h5>Sub Heading</h5>
                                            <br>
                                            
                                            <input class="form-control" type="text" value="<?php echo e($app_setting->app_sub_heading); ?>" name="sub_heading" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>       
                                        </div> <!-- col.// -->
                                        <div class="col-md-7">
                                            <div class="mb-3">
                                            <form method="post" action="/Admin/app_setting?setting=top_noti_1">
                                    <?php echo csrf_field(); ?>       
                                            <h5>Top Notification 1</h5>
                                            <br>
                                            
                                            <input class="form-control" type="text" value="<?php echo e($app_setting->top_bar_noti1); ?>" name="top_noti_1" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>
<form method="post" action="/Admin/app_setting?setting=top_noti_2">
                                    <?php echo csrf_field(); ?>       
                                            <h5>Top Notification 2</h5>
                                            <br>
                                            
                                            <input class="form-control" type="text" value="<?php echo e($app_setting->top_bar_noti2); ?>" name="top_noti_2" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>
                                            <br>
                                            <form method="post" action="/Admin/app_setting?setting=top_noti_3">
                                    <?php echo csrf_field(); ?>       
                                            <h5>Top Notification 3</h5>
                                            <br>
                                            
                                            <input class="form-control" type="text" value="<?php echo e($app_setting->top_bar_noti3); ?>" name="top_noti_3" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>
                                            </div>
                                        </div> <!-- col.// -->
                                    </div> <!-- row.// -->
                                    <div class="row border-bottom mb-4 pb-4">
                                      
                                         <center>
                                         <form method="post" enctype="multipart/form-data" action="/Admin/app_setting?setting=site_logo">
                                    <?php echo csrf_field(); ?>    
                                                <h5 >Site Logo</h5>
                                                <br>
                                                <input type="file" class="form-control" name="logo_file"><br>
      <img src="<?php echo e(asset('/site_logo')); ?>/<?php echo e($app_setting->app_logo); ?>"style="width:150px;">
      <p style="color:red;">*Only JPG,JPEG,PNG file supported</p>
</center>
<button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>    
                                    </div> <!-- row.// -->
                                    <div class="row border-bottom mb-4 pb-4">
                                    <center>
                                    <form method="post" action="/Admin/app_setting?setting=facebook">
                                    <?php echo csrf_field(); ?>    
                                            <h5>Facebook</h5>
                                            <br>
                                            <input class="form-control" type="text" value="<?php echo e($app_setting->facebook); ?>" name="facebook" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>             
                                           
<form method="post" action="/Admin/app_setting?setting=twitter">
                                    <?php echo csrf_field(); ?>    
                                            <h5>Twitter</h5>
                                            <br>
                                            <input class="form-control" type="text" value="<?php echo e($app_setting->twitter); ?>" name="twitter" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>             
<form method="post" action="/Admin/app_setting?setting=youtube">
                                    <?php echo csrf_field(); ?>    
                                            <h5>Youtube</h5>
                                            <br>
                                            <input class="form-control" type="text" value="<?php echo e($app_setting->youtube); ?>" name="youtube" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>             
<form method="post" action="/Admin/app_setting?setting=instagram">
                                    <?php echo csrf_field(); ?>    
                                            <h5>Instagram</h5>
                                            <br>
                                            <input class="form-control" type="text" value="<?php echo e($app_setting->insta); ?>" name="instagram" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>             
                                            <br>
                                            <form method="post" action="/Admin/app_setting?setting=linkdin">
                                    <?php echo csrf_field(); ?>    
                                            <h5>LinkdIn</h5>
                                            <br>
                                            <input class="form-control" type="text" value="<?php echo e($app_setting->linkedin); ?>"  name="linkdin" placeholder="Type here">
                                            <br>
                                            <button class="btn btn-primary" type="submit">Save changes</button> &nbsp;
                                            <br>
                                             <br>
</form>             
</center>
                                    </div> <!-- row.// -->
                                   
                                   
                            </section> <!-- content-body .// -->
                        </div> <!-- col.// -->
                    </div> <!-- row.// -->
               
           
        </section> <!-- content-main end// -->
 <?php $__env->stopSection(); ?>       
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\my project\Freelance\Freelance\resources\views//Admin/site_setting.blade.php ENDPATH**/ ?>