<?php $__env->startSection('content'); ?>

    <?php
    $count = 0;
    ?>

    <?php $__currentLoopData = $selected_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected_products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php
            $count = $count + $selected_products->total_price->price * $selected_products->quanity;

            // $final_price = $my_carts->total_price->price + $count;

        ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <style>
        body {
            font-family: Arial, Sans;
            margin: 0;
        }

        .wrapper {
            position: absolute;
            top: 50%;
            left: 50%;
            width: 300px;
            text-align: center;
            transform: translateX(-50%);
        }

        .spanner {
            position: absolute;
            top: 50%;
            left: 0;
            background: #2a2a2a55;
            width: 100%;
            display: block;
            text-align: center;
            height: 300px;
            color: #FFF;
            transform: translateY(-50%);
            z-index: 1000;
            visibility: hidden;
        }

        .overlay {
            /* position: fixed; */
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            visibility: hidden;
        }

        .loader,
        .loader:before,
        .loader:after {
            border-radius: 50%;
            width: 2.5em;
            height: 2.5em;
            -webkit-animation-fill-mode: both;
            animation-fill-mode: both;
            -webkit-animation: load7 1.8s infinite ease-in-out;
            animation: load7 1.8s infinite ease-in-out;
        }

        .loader {
            color: #ffffff;
            font-size: 10px;
            margin: 80px auto;
            position: relative;
            text-indent: -9999em;
            -webkit-transform: translateZ(0);
            -ms-transform: translateZ(0);
            transform: translateZ(0);
            -webkit-animation-delay: -0.16s;
            animation-delay: -0.16s;
        }

        .loader:before,
        .loader:after {
            content: '';
            position: absolute;
            top: 0;
        }

        .loader:before {
            left: -3.5em;
            -webkit-animation-delay: -0.32s;
            animation-delay: -0.32s;
        }

        .loader:after {
            left: 3.5em;
        }

        @-webkit-keyframes load7 {

            0%,
            80%,
            100% {
                box-shadow: 0 2.5em 0 -1.3em;
            }

            40% {
                box-shadow: 0 2.5em 0 0;
            }
        }

        @keyframes  load7 {

            0%,
            80%,
            100% {
                box-shadow: 0 2.5em 0 -1.3em;
            }

            40% {
                box-shadow: 0 2.5em 0 0;
            }
        }

        .show {
            visibility: visible;
        }

        .spanner,
        .overlay {
            opacity: 0;
            -webkit-transition: all 0.3s;
            -moz-transition: all 0.3s;
            transition: all 0.3s;
        }

        .spanner.show,
        .overlay.show {
            opacity: 1
        }

    </style>
    <div class="page-title-overlap bg-accent pt-4">
        <div class="container d-lg-flex justify-content-between py-2 py-lg-3">
            <div class="order-lg-2 mb-3 mb-lg-0 pt-lg-2">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb breadcrumb-light flex-lg-nowrap justify-content-center justify-content-lg-start">
                        <li class="breadcrumb-item"><a class="text-nowrap" href="/home"><i class="ci-home"></i>Home</a>
                        </li>
                        <li class="breadcrumb-item text-nowrap"><a href="#">Market</a>
                        </li>
                        <li class="breadcrumb-item text-nowrap active" aria-current="page">Checkout</li>
                    </ol>
                </nav>
            </div>
            <div class="order-lg-1 pe-lg-4 text-center text-lg-start">
                <h1 class="h3 text-light mb-0">Checkout</h1>
            </div>
        </div>
    </div>

    <div class="container mb-5 pb-3">

        <div class="overlay"></div>
        <div class="spanner">
            <div class="loader spinner-border text-danger" role="status">
                <span class="sr-only">Loading...</span>
            </div>
            <p>Looks perfect! You are just one more step away.</p>
        </div>
        <div class="bg-light shadow-lg rounded-3 overflow-hidden">
            <div class="row">
                <!-- Content-->
                <section class="col-lg-8 pt-2 pt-lg-4 pb-4 mb-3">
                    <div class="pt-2 px-4 pe-lg-0 ps-xl-5">
                        <!-- Title-->
                        <form method="post" style="display: block;" id="billing">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" id="token" value="<?php echo e(csrf_token()); ?>">
                            <h2 class="h6 border-bottom pb-3 mb-3">Billing details</h2>
                            <!-- Billing detail-->

                            <div class="row pb-4 gx-4 gy-3">
                                <div class="col-sm-6">
                                    <label class="form-label" for="mc-fn">First name <span
                                            class="text-danger">*</span></label>
                                    <input class="form-control" type="text" name="first_name"
                                        value="<?php echo e(Auth::user()->first_name); ?>" id="mc-fn">
                                </div>
                                <div class="col-sm-6">
                                    <label class="form-label" for="mc-ln">Last name <span
                                            class="text-danger">*</span></label>
                                    <input class="form-control" type="text" value="<?php echo e(Auth::user()->last_name); ?>"
                                        name="last_name" id="mc-ln">
                                </div>
                                <div class="col-12">
                                    <label class="form-label" for="mc-email">Email address <span
                                            class="text-danger">*</span></label>
                                    <input class="form-control" type="email" name="email"
                                        value="<?php echo e(Auth::user()->email); ?>" id="mc-email">
                                </div>
                                <div class="col-sm-6">
                                    <label class="form-label" for="mc-company">Company</label>
                                    <input class="form-control" type="text" name="company" id="mc-company">
                                </div>
                                <div class="col-sm-6">
                                    <label class="form-label" for="mc-country">Country <span
                                            class="text-danger">*</span></label>
                                    <select class="form-select" name="country" id="mc-country">
                                        <option value="">Select country</option>

                                        <option value="India" selected="">India</option>

                                    </select>
                                </div>
                                <div class="col-sm-6">
                                    <input class="btn btn-primary" type="submit" value="Next">
                                </div>

                            </div>
                        </form>
                        <!-- Order preview on mobile (screens small than 991px)-->

                        <!-- Payment methods accordion-->
                        <div class="accordion mb-2" id="payment-method" role="tablist" style="display: none;">
                            <div class="accordion-item">
                                <h3 class="accordion-header">
                                    <a class="accordion-button" href="#card" data-bs-toggle="collapse">
                                        <i class="ci-card fs-lg me-2 mt-n1 align-middle"></i>Pay with Payment</a>
                                </h3>
                                <div class="accordion-collapse collapse show" id="card" data-bs-parent="#payment-method"
                                    role="tabpanel">
                                    <div class="accordion-body">

                                        <p class="fs-sm">We accept following credit cards:&nbsp;&nbsp;<img
                                                class="d-inline-block align-middle" src="img/cards.png"
                                                style="width: 187px;" alt="Cerdit Cards"></p>
                                        <div class="credit-card-wrapper"></div>
                                        <form class="credit-card-form row g-3" action="/order_confirm" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="col-sm-6">
                                                <input class="form-control" type="text" name="number"
                                                    placeholder="Card Number" required="">
                                            </div>
                                            <div class="col-sm-6">
                                                <input class="form-control" type="text" name="name" placeholder="Full Name"
                                                    required="">
                                            </div>
                                            <div class="col-sm-3">
                                                <input class="form-control" type="text" name="expiry" placeholder="MM/YY"
                                                    required="">
                                            </div>
                                            <div class="col-sm-3">
                                                <input class="form-control" type="text" name="cvc" placeholder="CVC"
                                                    required="">
                                            </div>
                                            <input type="hidden" name="product_id" id="" value="<?php $__currentLoopData = $selected_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected_products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($selected_products->product_id); ?>, <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
                                            <div class="col-sm-6">
                                                <button class="btn btn-primary d-block w-100" type="submit">Place
                                                    order</button>
                                            </div>
                                            <div class="col-sm-6">
                                                <div class="row">
                                                    <div class="container col-sm-1">
                                                        <input type="checkbox" name="" required="" id="terms_condition">
                                                    </div>
                                                    <div class="container col-sm-11">
                                                        <label for="terms_condition">I agree with term &
                                                            condition</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="accordion-item">
                                <h3 class="accordion-header"><a class="accordion-button collapsed" href="#points"
                                        data-bs-toggle="collapse"><i class="ci-money-bag me-2"></i>Pay On QR Code</a></h3>
                                <div class="accordion-collapse collapse" id="points" data-bs-parent="#payment-method"
                                    role="tabpanel">
                                    <div class="accordion-body">
                                        <img src="<?php echo e(asset('/front/qr_code/qr_code.jpg')); ?>" alt="" srcset=""
                                            class="img-thumbnail" style="width:230px;"><br>
                                        <p>Currently you have to pay
                                            <span class="fw-medium">&nbsp;INR.
                                                <?php echo e($count); ?>.<small>00</small></span>
                                        </p>

                                        <input type="checkbox" name="" required="" id="terms_condition">
                                        I agree with term & condition
                                        <button class="btn btn-primary" type="submit">Place Order Now</button>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </section>
                <!-- Sidebar-->
                <!-- Order preview on desktop (screens larger than 991px)-->
                <aside class="col-lg-4 d-none d-lg-block ps-xl-5">
                    <hr class="d-lg-none">
                    <div class="p-4 h-100 ms-auto border-start">
                        <div class="widget px-lg-2 py-2 mb-3">
                            <h2 class="widget-title text-center">Order summary</h2>

                            <?php $__currentLoopData = $selected_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $selected_products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <div class="d-flex align-items-center pb-2 border-bottom">
                                    <a class="d-block flex-shrink-0 me-2" href="marketplace-single.html">
                                        <img class="rounded-1"
                                            src="<?php echo e(asset('/front/img/marketplace/products')); ?>/<?php echo e($selected_products->product_thumbnail()->product_image); ?>"
                                            alt="Product" width="100">
                                    </a>
                                    <div class="ps-1">
                                        <h6 class="widget-product-title">
                                            <a href="#"><?php echo e($selected_products->product_details()->title); ?></a>
                                        </h6>
                                        <div class="widget-product-meta">
                                            <span
                                                class="text-accent border-end pe-2 me-2">INR.<?php echo e($selected_products->product_details()->price); ?>.
                                                <small>00</small>
                                            </span>
                                        </div>
                                    </div>
                                </div>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <ul class="list-unstyled fs-sm pt-3 pb-2 border-bottom">
                                <li class="d-flex justify-content-between align-items-center"><span
                                        class="me-2">Subtotal:</span><span class="text-end">INR


                                        <?php echo e($count); ?>

                                    </span>
                                </li>
                            </ul>
                            <h3 class="fw-normal text-center my-4">INR <?php echo e($count); ?>.<small>00</small></h3>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    </div>
    <script>
        // Add record
        $('#billing').submit(function(e) {


            e.preventDefault();

            var form = new FormData(document.getElementById('billing'));
            var token = $('#token').val();
            form.append('_token', token);
            var x = document.getElementById("myAudio");

            $.ajax({
                url: '/save_billing_details',
                type: 'post',
                data: form,
                cache: false,
                contentType: false, //must, tell jQuery not to process the data
                processData: false,

                success: function(response) {

                    if (response.success === "billing_Save") {
                        document.getElementById('payment-method').style.display = "block";
                        document.getElementById('billing').style.display = "none";

                        $("div.spanner").removeClass("show");
                        $("div.overlay").removeClass("show");
                    }
                }
            });


        });
    </script>
    <script>
        $("input[type='submit']").click(function() {
            $("div.spanner").addClass("show");
            $("div.overlay").addClass("show");
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\my project\Freelance\Freelance\resources\views/checkout.blade.php ENDPATH**/ ?>