<?php $__env->startSection('content'); ?>
    <div class="page-title-overlap bg-accent pt-4">
        <div class="container d-lg-flex justify-content-between py-2 py-lg-3">
            <div class="order-lg-2 mb-3 mb-lg-0 pt-lg-2">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb breadcrumb-light flex-lg-nowrap justify-content-center justify-content-lg-start">
                        <li class="breadcrumb-item"><a class="text-nowrap" href="/home"><i class="ci-home"></i>Home</a>
                        </li>
                        <li class="breadcrumb-item text-nowrap"><a href="#">Market</a>
                        </li>
                        <li class="breadcrumb-item text-nowrap active" aria-current="page"><?php echo e($product->title); ?></li>
                    </ol>
                </nav>
            </div>
            <div class="order-lg-1 pe-lg-4 text-center text-lg-start">
                <h1 class="h3 text-light mb-0"><?php echo e($product->title); ?></h1>
            </div>
        </div>
    </div>

    <section class="container mb-3 pb-3">
        <div class="bg-light shadow-lg rounded-3 overflow-hidden">
            <div class="row">
                <!-- Content-->
                <section class="col-lg-8 pt-2 pt-lg-4 pb-4 mb-lg-3">
                    <div class="pt-3 px-4 pe-lg-0 ps-xl-5">
                        <!-- Product gallery-->
                        <div class="gallery">
                            <a class="gallery-item rounded-3 mb-grid-gutter"
                                href="/front/img/marketplace/products/<?php echo e($product->product_thumbnail()->product_image); ?>"
                                data-sub-html="<h6 class=&quot;fs-sm text-light&quot;>Simple iPhone X Mockups</h6>">

                                <img src="/front/img/marketplace/products/<?php echo e($product->product_thumbnail()->product_image); ?>"
                                    alt="Gallery preview">
                                <span class="gallery-item-caption"><?php echo e($product->title); ?></span></a>
                            <div class="row">
                                <?php $__currentLoopData = $product->product_all_imgs(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $images): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <div class="col-sm-3">
                                        <a class="gallery-item rounded-3 mb-grid-gutter"
                                            href="/front/img/marketplace/products/<?php echo e($images->product_image); ?>"
                                            data-sub-html="<h6 class=&quot;fs-sm text-light&quot;>UI Psd iPhone X Monochrome</h6>"><img
                                                src="/front/img/marketplace/products/<?php echo e($images->product_image); ?>"
                                                alt="Gallery preview">
                                            
                                        </a>

                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                        </div>
                        <!-- Wishlist + Sharing-->
                        <div class="d-flex flex-wrap justify-content-between align-items-center border-top pt-3">
                            <div class="py-2 me-2">
                                <button class="btn btn-outline-accent" type="button">
                                    <i class="ci-chat fs-lg me-2"></i>
                                    3 Comments</button>
                            </div>
                            <div class="py-2">

                                <a class="btn-social bs-outline bs-facebook bs-sm ms-2"
                                    href="https://www.facebook.com/sharer/sharer.php?u=http://127.0.0.1:8000/Product-Details/<?php echo e($product->id); ?>/<?php echo e(str_replace(' ', '-', $product->title)); ?>">
                                    <i class="ci-facebook"></i></a>
                                <a class="btn-social bs-outline bs-twitter bs-sm ms-2"
                                    href="https://twitter.com/intent/tweet?text=<?php echo e($product->details); ?>">
                                    <i class="ci-twitter"></i></a>
                            </div>
                        </div>
                    </div>
                </section>
                <!-- Sidebar-->
                <aside class="col-lg-4 ps-xl-5">
                    <hr class="d-lg-none">
                    <div class="bg-white h-100 p-4 ms-auto border-start">
                        <div class="px-lg-2">
                            <button class="btn btn-primary btn-shadow d-block w-100 mt-4" type="button">
                                <i class="ci-cart fs-lg me-2"></i>Add to Cart
                            </button>
                            <br>
                            <div class="bg-secondary rounded p-3 mb-2">
                                <i class="ci-download h5 text-muted align-middle mb-0 mt-n1 me-2"></i>
                                <span class="d-inline-block h6 mb-0 me-1">715</span><span class="fs-sm">Sales</span>
                            </div>
                            <div class="bg-secondary rounded p-3 mb-4">
                                <div class="star-rating">
                                    <i class="star-rating-icon ci-star-filled active"></i>
                                    <i class="star-rating-icon ci-star-filled active"></i>
                                    <i class="star-rating-icon ci-star-filled active"></i>
                                    <i class="star-rating-icon ci-star-filled active"></i>
                                    <i class="star-rating-icon ci-star"></i>
                                </div><span class="fs-ms ms-2">4.1/5</span>
                                <div class="fs-ms text-muted">based on 74 reviews</div>
                            </div>
                            <ul class="list-unstyled fs-sm">
                                <li class="d-flex justify-content-between mb-3 pb-3 border-bottom"><span
                                        class="text-dark fw-medium">Last update</span><span class="text-muted">April 27,
                                        2019</span></li>
                                <li class="d-flex justify-content-between mb-3 pb-3 border-bottom"><span
                                        class="text-dark fw-medium">Released</span><span class="text-muted">February 13,
                                        2019</span></li>
                                <li class="d-flex justify-content-between mb-3 pb-3 border-bottom"><span
                                        class="text-dark fw-medium">Category</span><a class="product-meta"
                                        href="#">Graphics</a></li>
                                <li class="d-flex justify-content-between mb-3 pb-3 border-bottom"><span
                                        class="text-dark fw-medium">Compatible with</span><span class="text-muted">Photoshop
                                        CS5</span>
                                </li>
                                <li class="d-flex justify-content-between mb-3 pb-3 border-bottom"><span
                                        class="text-dark fw-medium">File type</span><span class="text-muted">PSD, JPG</span>
                                </li>
                                <li class="d-flex justify-content-between pb-3 border-bottom"><span
                                        class="text-dark fw-medium">File
                                        size</span><span class="text-muted">56 MB</span></li>
                            </ul>
                        </div>
                    </div>
                </aside>
            </div>
        </div>
    </section>
    <section class="container mb-4 mb-lg-5">
        <!-- Nav tabs-->
        <ul class="nav nav-tabs" role="tablist">
            <li class="nav-item">
                <a class="nav-link p-4" href="#details" data-bs-toggle="tab" role="tab" aria-selected="false">
                    Product details
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link p-4" href="#reviews" data-bs-toggle="tab" role="tab">Reviews</a>
            </li>
            <li class="nav-item">
                <a class="nav-link p-4 active" href="#comments" data-bs-toggle="tab" role="tab" aria-selected="true">
                    Comments
                </a>
            </li>
        </ul>
        <div class="tab-content pt-2">
            <!-- Product details tab-->
            <div class="tab-pane fade" id="details" role="tabpanel">
                <div class="row">
                    <div class="col-lg-8">
                        <p class="fs-md">Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                            incididunt
                            ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco
                            laboris
                            nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
                            velit esse
                            cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
                            culpa
                            qui officia deserunt mollit anim id est laborum.</p>
                        <h3 class="h5 pt-2">Main features</h3>
                        <ul class="fs-md">
                            <li>Nemo enim ipsam voluptatem quia voluptas sit</li>
                            <li>Ut enim ad minima veniam, quis nostrum exercitationem</li>
                            <li>Duis aute irure dolor in reprehenderit in voluptate</li>
                            <li>At vero eos et accusamus et iusto odio dignissimos</li>
                            <li>Omnis voluptas assumenda est omnis dolor</li>
                            <li>Quis autem vel eum iure reprehenderit qui in ea voluptate</li>
                        </ul>
                    </div>
                </div>
            </div>
            <!-- Reviews tab-->
            <div class="tab-pane fade" id="reviews" role="tabpanel">
                <!-- Reviews-->
                <div class="row pt-2 pb-3">
                    <div class="col-lg-4 col-md-5">
                        <h3 class="h4 mb-4">74 Reviews</h3>
                        <div class="star-rating me-2"><i class="ci-star-filled fs-sm text-accent me-1"></i><i
                                class="ci-star-filled fs-sm text-accent me-1"></i><i
                                class="ci-star-filled fs-sm text-accent me-1"></i><i
                                class="ci-star-filled fs-sm text-accent me-1"></i><i
                                class="ci-star fs-sm text-muted me-1"></i></div>
                        <span class="d-inline-block align-middle">4.1 Overall rating</span>
                        <p class="pt-3 fs-sm text-muted">58 out of 74 (77%)<br>Customers recommended this product</p>
                    </div>
                    <div class="col-lg-8 col-md-7">
                        <div class="d-flex align-items-center mb-2">
                            <div class="text-nowrap me-3"><span class="d-inline-block align-middle text-muted">5</span><i
                                    class="ci-star-filled fs-xs ms-1"></i></div>
                            <div class="w-100">
                                <div class="progress" style="height: 4px;">
                                    <div class="progress-bar bg-success" role="progressbar" style="width: 60%;"
                                        aria-valuenow="60" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div><span class="text-muted ms-3">43</span>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <div class="text-nowrap me-3"><span class="d-inline-block align-middle text-muted">4</span><i
                                    class="ci-star-filled fs-xs ms-1"></i></div>
                            <div class="w-100">
                                <div class="progress" style="height: 4px;">
                                    <div class="progress-bar" role="progressbar"
                                        style="width: 27%; background-color: #a7e453;" aria-valuenow="27" aria-valuemin="0"
                                        aria-valuemax="100"></div>
                                </div>
                            </div><span class="text-muted ms-3">16</span>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <div class="text-nowrap me-3"><span class="d-inline-block align-middle text-muted">3</span><i
                                    class="ci-star-filled fs-xs ms-1"></i></div>
                            <div class="w-100">
                                <div class="progress" style="height: 4px;">
                                    <div class="progress-bar" role="progressbar"
                                        style="width: 17%; background-color: #ffda75;" aria-valuenow="17" aria-valuemin="0"
                                        aria-valuemax="100"></div>
                                </div>
                            </div><span class="text-muted ms-3">9</span>
                        </div>
                        <div class="d-flex align-items-center mb-2">
                            <div class="text-nowrap me-3"><span class="d-inline-block align-middle text-muted">2</span><i
                                    class="ci-star-filled fs-xs ms-1"></i></div>
                            <div class="w-100">
                                <div class="progress" style="height: 4px;">
                                    <div class="progress-bar" role="progressbar"
                                        style="width: 9%; background-color: #fea569;" aria-valuenow="9" aria-valuemin="0"
                                        aria-valuemax="100"></div>
                                </div>
                            </div><span class="text-muted ms-3">4</span>
                        </div>
                        <div class="d-flex align-items-center">
                            <div class="text-nowrap me-3"><span class="d-inline-block align-middle text-muted">1</span><i
                                    class="ci-star-filled fs-xs ms-1"></i></div>
                            <div class="w-100">
                                <div class="progress" style="height: 4px;">
                                    <div class="progress-bar bg-danger" role="progressbar" style="width: 4%;"
                                        aria-valuenow="4" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div><span class="text-muted ms-3">2</span>
                        </div>
                    </div>
                </div>
                <hr class="mt-4 mb-3">
                <div class="row py-4">
                    <!-- Reviews list-->
                    <div class="col-md-7">
                        <div class="d-flex justify-content-end pb-4">
                            <div class="d-flex align-items-center flex-nowrap">
                                <label class="fs-sm text-muted text-nowrap me-2 d-none d-sm-block" for="sort-reviews">Sort
                                    by:</label>
                                <select class="form-select form-select-sm" id="sort-reviews">
                                    <option>Newest</option>
                                    <option>Oldest</option>
                                    <option>Popular</option>
                                    <option>High rating</option>
                                    <option>Low rating</option>
                                </select>
                            </div>
                        </div>
                        <!-- Review-->
                        <div class="product-review pb-4 mb-4 border-bottom">
                            <div class="d-flex mb-3">
                                <div class="d-flex align-items-center me-4 pe-2">
                                    <img class="rounded-circle" src="img/shop/reviews/01.jpg" alt="Rafael Marquez"
                                        width="50">
                                    <div class="ps-3">
                                        <h6 class="fs-sm mb-0">Rafael Marquez</h6>
                                        <span class="fs-ms text-muted">June 28,
                                            2019</span>
                                    </div>
                                </div>
                                <div>
                                    <div class="star-rating"><i class="star-rating-icon ci-star-filled active"></i><i
                                            class="star-rating-icon ci-star-filled active"></i><i
                                            class="star-rating-icon ci-star-filled active"></i><i
                                            class="star-rating-icon ci-star-filled active"></i><i
                                            class="star-rating-icon ci-star"></i>
                                    </div>
                                    <div class="fs-ms text-muted">83% of users found this review helpful</div>
                                </div>
                            </div>
                            <p class="fs-md mb-2">Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil
                                impedit quo
                                minus id quod maxime placeat facere possimus, omnis voluptas assumenda est...</p>
                            <ul class="list-unstyled fs-ms pt-1">
                                <li class="mb-1"><span class="fw-medium">Pros:&nbsp;</span>Consequuntur magni, voluptatem
                                    sequi,
                                    tempora</li>
                                <li class="mb-1"><span class="fw-medium">Cons:&nbsp;</span>Architecto beatae, quis autem
                                </li>
                            </ul>
                            <div class="text-nowrap">
                                <button class="btn-like" type="button">15</button>
                                <button class="btn-dislike" type="button">3</button>
                            </div>
                        </div>
                        <!-- Review-->


                        <div class="text-center">
                            <button class="btn btn-outline-accent" type="button"><i class="ci-reload me-2"></i>Load more
                                reviews</button>
                        </div>
                    </div>
                    <?php if(!Auth::user()): ?>
                        <!-- Leave review form-->
                        <div class="col-md-5 mt-2 pt-4 mt-md-0 pt-md-0">
                            <div class="bg-secondary py-grid-gutter px-grid-gutter rounded-3">
                                <h3 class="h4 pb-2">Write a review</h3>
                                <form class="needs-validation" method="post" novalidate="">
                                    <div class="mb-3">
                                        <label class="form-label" for="review-name">Your name<span
                                                class="text-danger">*</span></label>
                                        <input class="form-control" type="text" required="" id="review-name">
                                        <div class="invalid-feedback">Please enter your name!</div><small
                                            class="form-text text-muted">Will
                                            be displayed on the comment.</small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" for="review-email">Your email<span
                                                class="text-danger">*</span></label>
                                        <input class="form-control" type="email" required="" id="review-email">
                                        <div class="invalid-feedback">Please provide valid email address!</div><small
                                            class="form-text text-muted">Authentication only - we won't spam you.</small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" for="review-rating">Rating<span
                                                class="text-danger">*</span></label>
                                        <select class="form-select" required="" id="review-rating">
                                            <option value="">Choose rating</option>
                                            <option value="5">5 stars</option>
                                            <option value="4">4 stars</option>
                                            <option value="3">3 stars</option>
                                            <option value="2">2 stars</option>
                                            <option value="1">1 star</option>
                                        </select>
                                        <div class="invalid-feedback">Please choose rating!</div>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" for="review-text">Review<span
                                                class="text-danger">*</span></label>
                                        <textarea class="form-control" rows="6" required="" id="review-text"></textarea>
                                        <div class="invalid-feedback">Please write a review!</div><small
                                            class="form-text text-muted">Your
                                            review must be at least 50 characters.</small>
                                    </div>
                                    <div class="mb-3">
                                        <label class="form-label" for="review-pros">Pros</label>
                                        <textarea class="form-control" rows="2" placeholder="Separated by commas"
                                            id="review-pros"></textarea>
                                    </div>
                                    <div class="mb-3 mb-4">
                                        <label class="form-label" for="review-cons">Cons</label>
                                        <textarea class="form-control" rows="2" placeholder="Separated by commas"
                                            id="review-cons"></textarea>
                                    </div>
                                    <button class="btn btn-primary btn-shadow d-block w-100" type="submit">Submit a
                                        Review</button>
                                </form>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

            </div>

            <!-- Comments tab-->
            <div class="tab-pane fade active show" id="comments" role="tabpanel">
                <div class="row">
                    <div class="col-lg-8">
                        <?php if($comment_count > 0): ?>
                            <?php $__currentLoopData = $comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <!-- comment-->
                                <div class="d-flex align-items-start py-4 border-bottom">
                                    <img class="rounded-circle" src="<?php echo e(asset('/front/user_avatar/02.jpg')); ?>"
                                        alt="Laura Willson" width="50">
                                    <div class="ps-3">
                                        <div class="d-flex justify-content-between align-items-center mb-2">
                                            <h6 class="fs-md mb-0"><?php echo e($comments->user_info()->first_name); ?>

                                                <?php echo e($comments->user_info()->last_name); ?></h6>
                                            <a href="#modal-<?php echo e($comments->id); ?>" class="nav-link-style fs-sm fw-medium"
                                                type="button" data-bs-toggle="modal"><i class="ci-reply me-2"></i>Reply</a>
                                        </div>
                                        <p class="fs-md mb-1">
                                            <?php echo e($comments->comment); ?>

                                        </p><span class="fs-ms text-muted"><i class="ci-time align-middle me-2"></i>
                                            <?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $comments->created_at)->format('d-m-Y')); ?>

                                        </span>
                                        <?php if($comments->comment_reply_count() > 0): ?>

                                            <!-- comment reply-->
                                            <div class="d-flex align-items-start border-top pt-4 mt-4">
                                                <img class="rounded-circle"
                                                    src="<?php echo e(asset('/front/user_avatar/02.jpg')); ?>" alt="Sara Palson"
                                                    width="50">
                                                <div class="ps-3">
                                                    <div class="d-flex justify-content-between align-items-center mb-2">
                                                        <h6 class="fs-md mb-0">
                                                            <?php echo e($comments->comment_reply()->user_info()->first_name); ?>

                                                        </h6>
                                                    </div>
                                                    <p class="fs-md mb-1"><?php echo e($comments->comment_reply()->comment); ?></p>
                                                    <span class="fs-ms text-muted"><i
                                                            class="ci-time align-middle me-2"></i><?php echo e(\Carbon\Carbon::createFromFormat('Y-m-d H:i:s', $comments->comment_reply()->created_at)->format('d-m-Y')); ?></span>
                                                </div>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                                
                                <div class="modal fade" id="modal-<?php echo e($comments->id); ?>" tabindex="-1" role="dialog">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header bg-secondary">
                                                <h4>Reply </h4>
                                                <button class="btn-close" type="button" data-bs-dismiss="modal"
                                                    aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body tab-content py-4">

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>

                            <div class="d-flex align-items-start py-4 border-bottom">
                                <div class="container">
                                    <h4>No comments.</h4>
                                </div>
                            </div>

                        <?php endif; ?>
                        <?php if(Auth::check()): ?>
                            <!-- Post comment form-->
                            <?php if(session('comment_success')): ?>
                                <div class="alert alert-success"><?php echo e(session('comment_success')); ?></div>
                            <?php endif; ?>
                            <div class="card border-0 shadow my-2">
                                <div class="card-body">
                                    <div class="d-flex align-items-start">
                                        <img class="rounded-circle border p-2"
                                            src="<?php echo e(asset('/front/img/marketplace/account/avatar-sm.png')); ?>"
                                            alt="Createx Studio" width="50">
                                        <form class="needs-validation w-100 ms-3" novalidate=""
                                            action="/post_comment/<?php echo e($id); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="mb-3">
                                                <textarea class="form-control" rows="4" placeholder="Write comment..."
                                                    required="" name="comment"></textarea>
                                                <div class="invalid-feedback">Please write your comment.</div>
                                            </div>
                                            <button class="btn btn-primary btn-sm" type="submit">Post comment</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

    </section>
    <section class="container mb-5 pb-lg-3">
        <div class="d-flex flex-wrap justify-content-between align-items-center border-bottom pb-4 mb-4">
            <h2 class="h3 mb-0 pt-2">Related Products</h2>
            <div class="pt-2"><a class="btn btn-outline-accent btn-sm" href="marketplace-category.html">More mockups<i
                        class="ci-arrow-end ms-1 me-n1"></i></a></div>
        </div>
        <!-- Carousel-->
        <div class="row">

            <?php $__currentLoopData = $related_product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $related_products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="container col-sm-3">
                    <div class="card product-card-alt">
                        <div class="product-thumb">
                            <div class="product-card-actions">
                                <a class="btn btn-light btn-icon btn-shadow fs-base mx-2"
                                    href="/Product-Details/<?php echo e($related_products->id); ?>/<?php echo e(str_replace(' ', '-', $related_products->title)); ?>">
                                    <i class="ci-eye"></i>
                                </a>
                                <?php if(!Auth::check()): ?>

                                    <a href="#signin-modal" class="btn btn-light btn-icon btn-shadow fs-base mx-2"
                                        type="button" data-bs-toggle="modal">
                                        <i class="ci-cart"></i>
                                    </a>

                                <?php else: ?>
                                    <a href="/add_to_cart_from_front/<?php echo e($related_products->id); ?>"
                                        class="btn btn-light btn-icon btn-shadow fs-base mx-2" type="button">
                                        <i class="ci-cart"></i>
                                    </a>
                                <?php endif; ?>
                            </div>
                            <a class="product-thumb-overlay"
                                href="/Product-Details/<?php echo e($related_products->id); ?>/<?php echo e(str_replace(' ', '-', $related_products->title)); ?>"></a>
                            <img src="<?php echo e(asset('/front/img/marketplace/products')); ?>/<?php echo e($related_products->product_thumbnail()->product_image); ?>"
                                alt="<?php echo e($related_products->title); ?>">
                        </div>
                        <div class="card-body">
                            <div class="d-flex flex-wrap justify-content-between align-items-start pb-2">
                                <div class="text-muted fs-xs me-1">

                                    <a class="product-meta fw-medium" href="#"><i class="ci-tag"></i>
                                        <?php echo e($related_products->category->name); ?></a>
                                </div>
                                <div class="star-rating"><i class="star-rating-icon ci-star-filled active"></i><i
                                        class="star-rating-icon ci-star-filled active"></i><i
                                        class="star-rating-icon ci-star-filled active"></i><i
                                        class="star-rating-icon ci-star-filled active"></i><i
                                        class="star-rating-icon ci-star-filled active"></i>
                                </div>
                            </div>
                            <h3 class="product-title fs-sm mb-2">
                                <a
                                    href="/Product-Details/<?php echo e($related_products->id); ?>/<?php echo e(str_replace(' ', '-', $related_products->title)); ?>">
                                    <?php echo e($related_products->title); ?>

                                </a>
                            </h3>
                            <div class="d-flex flex-wrap justify-content-between align-items-center">
                                <div class="fs-sm me-2"><i class="ci-download text-muted me-1"></i>
                                    109
                                    <span class="fs-xs ms-1">Sales</span>
                                </div>
                                <div class="bg-faded-accent text-accent rounded-1 py-1 px-2">
                                    INR. <?php echo e($related_products->price); ?>.<small>00</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="tns-nav" aria-label="Carousel Pagination" style="display: none;"><button type="button" data-nav="0"
                aria-controls="tns1" style="display:none" aria-label="Carousel Page 1 (Current Slide)"
                class="tns-nav-active"></button><button type="button" data-nav="1" tabindex="-1" aria-controls="tns1"
                style="display:none" aria-label="Carousel Page 2"></button><button type="button" data-nav="2" tabindex="-1"
                aria-controls="tns1" style="display:none" aria-label="Carousel Page 3"></button><button type="button"
                data-nav="3" tabindex="-1" aria-controls="tns1" style="display:none" aria-label="Carousel Page 4"></button>
        </div>
        </div>
        </div>
    </section>
    <script src="<?php echo e(asset('/front/vendor/bootstrap/dist/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/front/vendor/simplebar/dist/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/front/vendor/tiny-slider/dist/min/tiny-slider.js')); ?>"></script>
    <script src="<?php echo e(asset('/front/vendor/smooth-scroll/dist/smooth-scroll.polyfills.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/front/vendor/lightgallery.js/dist/js/lightgallery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/front/vendor/lg-fullscreen.js/dist/lg-fullscreen.min.js')); ?>"></script>
    <script src="<?php echo e(asset('/front/vendor/lg-zoom.js/dist/lg-zoom.min.js')); ?>"></script>
    <!-- Main theme script-->
    <script src="<?php echo e(asset('/front/js/theme.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\program files\Freelance\resources\views/product_details.blade.php ENDPATH**/ ?>